﻿    var BaseUrl1 = window.location.origin;
    var BaseUrl = "https://customerapproval.marutisuzuki.com/mTab_QA";
    //var BaseUrl = "http://localhost:61481/";
    var selectData = [];

$('#abft1').change(function (e) {
    debugger;

    //32,33,34,35,36,37
    //27,28,29,30,31
    var LocCd = $('#LOC').val();
    var JobCardNo = $('#jc').val();
    var DealerMapCd1 = $('#DMC').val();
    var ParentGroup = $('#prg').val();
    var MediaPath = $("#abft1").get(0).files;
    var Vin = $("#Vin").val();
    var employee = new FormData();

    // var data = new FormData();
    //worklog = {
    //    LocCd: LocCd,
    //    DealerMapCd: DealerMapCd1,
    //    ParentGroup: ParentGroup,
    //   // MediaPath: MediaPath,
    //    JobCardNo: JobCardNo,
    //    DisplayOrder: '32',
    //    MediaType: 'RecallAfter-1',
    //}
    // selectData.push(worklog);

    //data.append("LocCd", LocCd);
    //data.append("DealerMapCd", DealerMapCd1);
    //data.append("ParentGroup", ParentGroup);
    //data.append("JobCardNo", JobCardNo);
    //data.append("DisplayOrder", 27);
    //data.append("Vin", Vin);
    //data.append("MediaType", 'Recall-1');
    employee.append(Vin + '_' + "RECALLBEFORE" + '_' + MediaPath[0], MediaPath[0]);

    //$.ajax({
    //    type: "POST",
    //    url: BaseUrl + "/Sync/SaveMultiPartImages",
    //    data: employee,//JSON.stringify(employee),
    //    contentType: false,
    //    processData: false,
    //    dataType: "json",
    //    async: "true",
    //    crossDomain: true,
    APIModule.Call('POST', BaseUrl + '/Sync/SaveMultiPartImages', employee).done(function (data) {
        debugger;

        console.log(data);

        console.log(response.RecallImageDetails[0].ImageUrl);

        var MediaPath = response.RecallImageDetails[0].ImageUrl;
        // data.append("MediaPath", MediaPath)

        worklog = {
            LocCd: LocCd,
            DealerMapCd: DealerMapCd1,
            ParentGroup: ParentGroup,
            MediaPath: MediaPath,
            JobCardNo: JobCardNo,
            DisplayOrder: '27',
            MediaType: 'Recall-1',
        }

        selectData.push(worklog);


        $.post(BaseUrl1 + '/Home/RecallReUpload', { Checkedstr: JSON.stringify(selectData) }, function (data) {
            //success code here
        });
        //$.ajax({
        //    type: "POST",
        //    url: BaseUrl1 + "/Home/UpdateRecallMediaPath",
        //    data: data,//JSON.stringify(employee),
        //    contentType: false,
        //    processData: false,
        //    dataType: "json",
        //    success: function (response) {
        //        if (response == 200) {
        //            alert('File Uploaded successfully');
        //            //location.reload();
        //            //$("#btnSearch").click();
        //        }
        //    },
        //});
    });
    //})

    //});


    var APIModule = (function () {
        var Call = function (RequestType, APIUrl, content) {
            return $.ajax({
                type: RequestType,
                url: APIUrl,
                data: content,
                contentType: "application/json; charset=utf-8",
                datatype: "json",
                async: "true",
                crossDomain: true
            });
        };
        function setHeader(xhr) {
            xhr.setRequestHeader('Access-Control-Allow-Origin', '*');
        }
        return {
            Call: Call
        }
    })();



    $('#abft2').change(function (e) {
        debugger;
        var data = new FormData();
        //32,33,34,35,36,37
        var LocCd = $('#LOC').val();
        var JobCardNo = $('#jc').val();
        var DealerMapCd1 = $('#DMC').val();
        var ParentGroup = $('#prg').val();
        var MediaPath = $("#abft1").get(0).files;
        data.append("LocCd", LocCd);
        data.append("DealerMapCd", DealerMapCd1);
        data.append("ParentGroup", ParentGroup);
        data.append("MediaPath", MediaPath);
        data.append("JobCardNo", JobCardNo);
        data.append("DisplayOrder", 32);
        data.append("MediaType", "RecallAfter-1");
        worklog = {
            LocCd: LocCd,
            DealerMapCd: DealerMapCd1,
            ParentGroup: ParentGroup,
            // MediaPath: MediaPath,
            JobCardNo: JobCardNo,
            DisplayOrder: '33',
            MediaType: 'RecallAfter-2',
        }

        selectData.push(worklog);
    });



    $("#btnreuplod").click(function () {
        debugger;
        $("#loader").show();

        $.post(BaseUrl1 + '/Home/RecallReUpload', { Checkedstr: JSON.stringify(selectData) }, function (data) {
            //success code here
        });
        //$.ajax({
        //    type: "POST",
        //    url: BaseUrl1 + "/Home/RecallReUpload",
        //    data: JSON.stringify(selectData),
        //    contentType: "application/json; charset=utf-8",
        //    dataType: "json",
        //    success: function (response) {
        //        if (response == 201) {
        //            $("#loader").hide();
        //            alert('Recall status re-submitted successfully.')
        //            $("#btnSearch").click();
        //        }
        //    },
        //    //failure: function (response) {
        //    //    alert(response.responseText);
        //    //},
        //    //error: function (response) {
        //    //    alert(response.responseText);
        //    //}
        //});
        //}
    });
}