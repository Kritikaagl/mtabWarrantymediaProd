﻿
$(document).ready(function () {
    $('.fancybox').fancybox();
});

$(document).on('click', '.appRejectRadioBtn .form-check-label input[type="radio"]', function () {
    $('.form-check-label').removeClass('selected');
    $(this).parent().addClass('selected');
});

$(".form-check-label.green").click(function () {
    $(".ctaSubmit").addClass("greenColor");
    $(".ctaSubmit").removeClass("redColor");
});

$(".form-check-label.red").click(function () {
    $(".ctaSubmit").addClass("redColor");
    $(".ctaSubmit").removeClass("greenColor");
});

var BaseUrl1 = window.location.origin;
var BaseUrl = "https://customerapproval.marutisuzuki.com/mTab_QA";
$('#file1').change(function (e) {
    debugger;
    var fileExtension = ['jpeg', 'jpg', 'png', 'gif', 'bmp'];
    if ($.inArray($(this).val().split('.').pop().toLowerCase(), fileExtension) == -1) {
        alert("Only formats are allowed : " + fileExtension.join(', '));
        return false;
    }
    var employee = new FormData();
    var MediaPath = $("#file1").get(0).files; //e.target.files[0].name;
    var ext = $('#file1').val().split('.').pop().toLowerCase();
    var MediaId = $("#mId1").val();
    var vin = $("#Vin").val();
    var MediaType = $("#rId1").val();
    var ImageUrl = $("#img1").val();
    var JCNo = $('#jc').val();
    var RegistrationNo = $('#RG').val();
    var Vin = $('#vin').val();
    var ParentGroup = $('#prg').val();
    var DealerCd = $('#DC').val();
    //copy
    var Recall = MediaType.includes("Recall-");
    if (Recall == true) {
        employee.append(vin + '_' + "RECALLBEFORE" + '_' + MediaPath[0], MediaPath[0]);
    }
    else {
        employee.append(vin + '_' + "RECALLAFTER" + '_' + MediaPath[0], MediaPath[0]);
    }

    var data = new FormData();
    //data.append("MediaPath", MediaPath);
    data.append("MediaId", MediaId);
    data.append("vin", vin);
    data.append("MediaType", MediaType);
    data.append("JCNo", JCNo);
    data.append("RegistrationNo", RegistrationNo);
    data.append("Vin", Vin);
    data.append("DealerCd", DealerCd);
    $.ajax({
        type: "POST",
        url: BaseUrl + "/Sync/SaveMultiPartImages",
        data: employee,//JSON.stringify(employee),
        contentType: false,
        processData: false,
        dataType: "json",
        success: function (response) {
            debugger;
            //response.RecallImageDetails[0].ImageUrl;
            console.log(response);
            console.log(response.RecallImageDetails[0].ImageUrl);
            var MediaPath = response.RecallImageDetails[0].ImageUrl;
            data.append("MediaPath", MediaPath)
            $.ajax({
                type: "POST",
                url: BaseUrl1 + "/Home/UpdateRecallMediaPath",
                data: data,//JSON.stringify(employee),
                contentType: false,
                processData: false,
                dataType: "json",
                success: function (response) {
                    if (response == 200) {
                        alert('File Uploaded successfully');
                    }
                },
            });
        },
    })
});

$('#file2').change(function (e) {
    debugger;
    var fileExtension = ['jpeg', 'jpg', 'png', 'gif', 'bmp'];
    if ($.inArray($(this).val().split('.').pop().toLowerCase(), fileExtension) == -1) {
        alert("Only formats are allowed : " + fileExtension.join(', '));
        return false;
    }
    var employee = new FormData();
    var MediaPath = $("#file2").get(0).files;
    var MediaId = $("#mId2").val();
    var vin = $("#Vin").val();
    var MediaType = $("#rId2").val();
    var ImageUrl = $("#img2").val();
    var JCNo = $('#jc').val();
    var RegistrationNo = $('#RG').val();
    var Vin = $('#vin').val();
    var ParentGroup = $('#prg').val();
    var DealerCd = $('#DC').val();
    var Recall = MediaType.includes("Recall-");
    if (Recall == true) {
        employee.append(vin + '_' + "RECALLBEFORE" + '_' + MediaPath[0], MediaPath[0]);
    }
    else {
        employee.append(vin + '_' + "RECALLAFTER" + '_' + MediaPath[0], MediaPath[0]);
    }

    var data = new FormData();
    //data.append("MediaPath", MediaPath);
    data.append("MediaId", MediaId);
    data.append("vin", vin);
    data.append("MediaType", MediaType);
    data.append("JCNo", JCNo);
    data.append("RegistrationNo", RegistrationNo);
    data.append("Vin", Vin);
    data.append("DealerCd", DealerCd);
    $.ajax({
        type: "POST",
        url: BaseUrl + "/Sync/SaveMultiPartImages",
        data: employee,//JSON.stringify(employee),
        contentType: false,
        processData: false,
        dataType: "json",
        success: function (response) {
            debugger;
            //response.RecallImageDetails[0].ImageUrl;
            console.log(response);
            console.log(response.RecallImageDetails[0].ImageUrl);
            var MediaPath = response.RecallImageDetails[0].ImageUrl;
            data.append("MediaPath", MediaPath)
            $.ajax({
                type: "POST",
                url: BaseUrl1 + "/Home/UpdateRecallMediaPath",
                data: data,//JSON.stringify(employee),
                contentType: false,
                processData: false,
                dataType: "json",
                success: function (response) {
                    if (response == 200) {
                        alert('File Uploaded successfully');
                    }
                },
            });
        },
    })
});

$('#file3').change(function (e) {
    debugger;
    var fileExtension = ['jpeg', 'jpg', 'png', 'gif', 'bmp'];
    if ($.inArray($(this).val().split('.').pop().toLowerCase(), fileExtension) == -1) {
        alert("Only formats are allowed : " + fileExtension.join(', '));
        return false;
    }
    var employee = new FormData();
    var MediaPath = $("#file3").get(0).files;
    var MediaId = $("#mId3").val();
    var vin = $("#Vin").val();
    var MediaType = $("#rId3").val();
    var ImageUrl = $("#img3").val();
    var JCNo = $('#jc').val();
    var RegistrationNo = $('#RG').val();
    var Vin = $('#vin').val();
    var ParentGroup = $('#prg').val();
    var DealerCd = $('#DC').val();
    var Recall = MediaType.includes("Recall-");
    if (Recall == true) {
        employee.append(vin + '_' + "RECALLBEFORE" + '_' + MediaPath[0], MediaPath[0]);
    }
    else {
        employee.append(vin + '_' + "RECALLAFTER" + '_' + MediaPath[0], MediaPath[0]);
    }

    var data = new FormData();
    //data.append("MediaPath", MediaPath);
    data.append("MediaId", MediaId);
    data.append("vin", vin);
    data.append("MediaType", MediaType);
    data.append("JCNo", JCNo);
    data.append("RegistrationNo", RegistrationNo);
    data.append("Vin", Vin);
    data.append("DealerCd", DealerCd);
    $.ajax({
        type: "POST",
        url: BaseUrl + "/Sync/SaveMultiPartImages",
        data: employee,//JSON.stringify(employee),
        contentType: false,
        processData: false,
        dataType: "json",
        success: function (response) {
            debugger;
            //response.RecallImageDetails[0].ImageUrl;
            console.log(response);
            console.log(response.RecallImageDetails[0].ImageUrl);
            var MediaPath = response.RecallImageDetails[0].ImageUrl;
            data.append("MediaPath", MediaPath)
            $.ajax({
                type: "POST",
                url: BaseUrl1 + "/Home/UpdateRecallMediaPath",
                data: data,//JSON.stringify(employee),
                contentType: false,
                processData: false,
                dataType: "json",
                success: function (response) {
                    if (response == 200) {
                        alert('File Uploaded successfully');
                    }
                },
            });
        },
    })
});

$('#file4').change(function (e) {
    debugger;
    var fileExtension = ['jpeg', 'jpg', 'png', 'gif', 'bmp'];
    if ($.inArray($(this).val().split('.').pop().toLowerCase(), fileExtension) == -1) {
        alert("Only formats are allowed : " + fileExtension.join(', '));
        return false;
    }
    var employee = new FormData();
    var MediaPath = $("#file4").get(0).files;
    var MediaId = $("#mId4").val();
    var vin = $("#Vin").val();
    var MediaType = $("#rId4").val();
    var ImageUrl = $("#img4").val();
    var JCNo = $('#jc').val();
    var RegistrationNo = $('#RG').val();
    var Vin = $('#vin').val();
    var ParentGroup = $('#prg').val();
    var DealerCd = $('#DC').val();
    var Recall = MediaType.includes("Recall-");
    if (Recall == true) {
        employee.append(vin + '_' + "RECALLBEFORE" + '_' + MediaPath[0], MediaPath[0]);
    }
    else {
        employee.append(vin + '_' + "RECALLAFTER" + '_' + MediaPath[0], MediaPath[0]);
    }

    var data = new FormData();
    //data.append("MediaPath", MediaPath);
    data.append("MediaId", MediaId);
    data.append("vin", vin);
    data.append("MediaType", MediaType);
    data.append("JCNo", JCNo);
    data.append("RegistrationNo", RegistrationNo);
    data.append("Vin", Vin);
    data.append("DealerCd", DealerCd);
    $.ajax({
        type: "POST",
        url: BaseUrl + "/Sync/SaveMultiPartImages",
        data: employee,//JSON.stringify(employee),
        contentType: false,
        processData: false,
        dataType: "json",
        success: function (response) {
            debugger;
            //response.RecallImageDetails[0].ImageUrl;
            console.log(response);
            console.log(response.RecallImageDetails[0].ImageUrl);
            var MediaPath = response.RecallImageDetails[0].ImageUrl;
            data.append("MediaPath", MediaPath)
            $.ajax({
                type: "POST",
                url: BaseUrl1 + "/Home/UpdateRecallMediaPath",
                data: data,//JSON.stringify(employee),
                contentType: false,
                processData: false,
                dataType: "json",
                success: function (response) {
                    if (response == 200) {
                        alert('File Uploaded successfully');
                    }
                },
            });
        },
    })
});

$('#file5').change(function (e) {
    debugger;
    var fileExtension = ['jpeg', 'jpg', 'png', 'gif', 'bmp'];
    if ($.inArray($(this).val().split('.').pop().toLowerCase(), fileExtension) == -1) {
        alert("Only formats are allowed : " + fileExtension.join(', '));
        return false;
    }
    var employee = new FormData();
    var MediaPath = $("#file5").get(0).files;
    var MediaId = $("#mId5").val();
    var vin = $("#Vin").val();
    var MediaType = $("#rId5").val();
    var ImageUrl = $("#img5").val();
    var JCNo = $('#jc').val();
    var RegistrationNo = $('#RG').val();
    var Vin = $('#vin').val();
    var ParentGroup = $('#prg').val();
    var DealerCd = $('#DC').val();
    var Recall = MediaType.includes("Recall-");
    if (Recall == true) {
        employee.append(vin + '_' + "RECALLBEFORE" + '_' + MediaPath[0], MediaPath[0]);
    }
    else {
        employee.append(vin + '_' + "RECALLAFTER" + '_' + MediaPath[0], MediaPath[0]);
    }

    var data = new FormData();
    //data.append("MediaPath", MediaPath);
    data.append("MediaId", MediaId);
    data.append("vin", vin);
    data.append("MediaType", MediaType);
    data.append("JCNo", JCNo);
    data.append("RegistrationNo", RegistrationNo);
    data.append("Vin", Vin);
    data.append("DealerCd", DealerCd);
    $.ajax({
        type: "POST",
        url: BaseUrl + "/Sync/SaveMultiPartImages",
        data: employee,//JSON.stringify(employee),
        contentType: false,
        processData: false,
        dataType: "json",
        success: function (response) {
            debugger;
            //response.RecallImageDetails[0].ImageUrl;
            console.log(response);
            console.log(response.RecallImageDetails[0].ImageUrl);
            var MediaPath = response.RecallImageDetails[0].ImageUrl;
            data.append("MediaPath", MediaPath)
            $.ajax({
                type: "POST",
                url: BaseUrl1 + "/Home/UpdateRecallMediaPath",
                data: data,//JSON.stringify(employee),
                contentType: false,
                processData: false,
                dataType: "json",
                success: function (response) {
                    if (response == 200) {
                        alert('File Uploaded successfully');
                    }
                },
            });
        },
    })
});

$('#file6').change(function (e) {
    debugger;
    var fileExtension = ['jpeg', 'jpg', 'png', 'gif', 'bmp'];
    if ($.inArray($(this).val().split('.').pop().toLowerCase(), fileExtension) == -1) {
        alert("Only formats are allowed : " + fileExtension.join(', '));
        return false;
    }
    var employee = new FormData();
    var MediaPath = $("#file6").get(0).files;
    var MediaId = $("#mId6").val();
    var vin = $("#Vin").val();
    var MediaType = $("#rId6").val();
    var ImageUrl = $("#img6").val();
    var JCNo = $('#jc').val();
    var RegistrationNo = $('#RG').val();
    var Vin = $('#vin').val();
    var ParentGroup = $('#prg').val();
    var DealerCd = $('#DC').val();
    var Recall = MediaType.includes("Recall-");
    if (Recall == true) {
        employee.append(vin + '_' + "RECALLBEFORE" + '_' + MediaPath[0], MediaPath[0]);
    }
    else {
        employee.append(vin + '_' + "RECALLAFTER" + '_' + MediaPath[0], MediaPath[0]);
    }

    var data = new FormData();
    //data.append("MediaPath", MediaPath);
    data.append("MediaId", MediaId);
    data.append("vin", vin);
    data.append("MediaType", MediaType);
    data.append("JCNo", JCNo);
    data.append("RegistrationNo", RegistrationNo);
    data.append("Vin", Vin);
    data.append("DealerCd", DealerCd);
    $.ajax({
        type: "POST",
        url: BaseUrl + "/Sync/SaveMultiPartImages",
        data: employee,//JSON.stringify(employee),
        contentType: false,
        processData: false,
        dataType: "json",
        success: function (response) {
            debugger;
            //response.RecallImageDetails[0].ImageUrl;
            console.log(response);
            console.log(response.RecallImageDetails[0].ImageUrl);
            var MediaPath = response.RecallImageDetails[0].ImageUrl;
            data.append("MediaPath", MediaPath)
            $.ajax({
                type: "POST",
                url: BaseUrl1 + "/Home/UpdateRecallMediaPath",
                data: data,//JSON.stringify(employee),
                contentType: false,
                processData: false,
                dataType: "json",
                success: function (response) {
                    if (response == 200) {
                        alert('File Uploaded successfully');
                    }
                },
            });
        },
    })
});

$('#file7').change(function (e) {
    debugger;
    var fileExtension = ['jpeg', 'jpg', 'png', 'gif', 'bmp'];
    if ($.inArray($(this).val().split('.').pop().toLowerCase(), fileExtension) == -1) {
        alert("Only formats are allowed : " + fileExtension.join(', '));
        return false;
    }
    var employee = new FormData();
    var MediaPath = $("#file7").get(0).files;
    var MediaId = $("#mId7").val();
    var vin = $("#Vin").val();
    var MediaType = $("#rId7").val();
    var ImageUrl = $("#img7").val();
    var JCNo = $('#jc').val();
    var RegistrationNo = $('#RG').val();
    var Vin = $('#vin').val();
    var ParentGroup = $('#prg').val();
    var DealerCd = $('#DC').val();
    var Recall = MediaType.includes("Recall-");
    if (Recall == true) {
        employee.append(vin + '_' + "RECALLBEFORE" + '_' + MediaPath[0], MediaPath[0]);
    }
    else {
        employee.append(vin + '_' + "RECALLAFTER" + '_' + MediaPath[0], MediaPath[0]);
    }

    var data = new FormData();
    //data.append("MediaPath", MediaPath);
    data.append("MediaId", MediaId);
    data.append("vin", vin);
    data.append("MediaType", MediaType);
    data.append("JCNo", JCNo);
    data.append("RegistrationNo", RegistrationNo);
    data.append("Vin", Vin);
    data.append("DealerCd", DealerCd);
    $.ajax({
        type: "POST",
        url: BaseUrl + "/Sync/SaveMultiPartImages",
        data: employee,//JSON.stringify(employee),
        contentType: false,
        processData: false,
        dataType: "json",
        success: function (response) {
            debugger;
            //response.RecallImageDetails[0].ImageUrl;
            console.log(response);
            console.log(response.RecallImageDetails[0].ImageUrl);
            var MediaPath = response.RecallImageDetails[0].ImageUrl;
            data.append("MediaPath", MediaPath)
            $.ajax({
                type: "POST",
                url: BaseUrl1 + "/Home/UpdateRecallMediaPath",
                data: data,//JSON.stringify(employee),
                contentType: false,
                processData: false,
                dataType: "json",
                success: function (response) {
                    if (response == 200) {
                        alert('File Uploaded successfully');
                    }
                },
            });
        },
    })
});

$('#file8').change(function (e) {
    debugger;
    var fileExtension = ['jpeg', 'jpg', 'png', 'gif', 'bmp'];
    if ($.inArray($(this).val().split('.').pop().toLowerCase(), fileExtension) == -1) {
        alert("Only formats are allowed : " + fileExtension.join(', '));
        return false;
    }
    var employee = new FormData();
    var MediaPath = $("#file8").get(0).files;
    var MediaId = $("#mId8").val();
    var vin = $("#Vin").val();
    var MediaType = $("#rId8").val();
    var ImageUrl = $("#img8").val();
    var JCNo = $('#jc').val();
    var RegistrationNo = $('#RG').val();
    var Vin = $('#vin').val();
    var ParentGroup = $('#prg').val();
    var DealerCd = $('#DC').val();
    var Recall = MediaType.includes("Recall-");
    if (Recall == true) {
        employee.append(vin + '_' + "RECALLBEFORE" + '_' + MediaPath[0], MediaPath[0]);
    }
    else {
        employee.append(vin + '_' + "RECALLAFTER" + '_' + MediaPath[0], MediaPath[0]);
    }

    var data = new FormData();
    //data.append("MediaPath", MediaPath);
    data.append("MediaId", MediaId);
    data.append("vin", vin);
    data.append("MediaType", MediaType);
    data.append("JCNo", JCNo);
    data.append("RegistrationNo", RegistrationNo);
    data.append("Vin", Vin);
    data.append("DealerCd", DealerCd);
    $.ajax({
        type: "POST",
        url: BaseUrl + "/Sync/SaveMultiPartImages",
        data: employee,//JSON.stringify(employee),
        contentType: false,
        processData: false,
        dataType: "json",
        success: function (response) {
            debugger;
            //response.RecallImageDetails[0].ImageUrl;
            console.log(response);
            console.log(response.RecallImageDetails[0].ImageUrl);
            var MediaPath = response.RecallImageDetails[0].ImageUrl;
            data.append("MediaPath", MediaPath)
            $.ajax({
                type: "POST",
                url: BaseUrl1 + "/Home/UpdateRecallMediaPath",
                data: data,//JSON.stringify(employee),
                contentType: false,
                processData: false,
                dataType: "json",
                success: function (response) {
                    if (response == 200) {
                        alert('File Uploaded successfully');
                    }
                },
            });
        },
    })
});

$('#file9').change(function (e) {
    debugger;
    var fileExtension = ['jpeg', 'jpg', 'png', 'gif', 'bmp'];
    if ($.inArray($(this).val().split('.').pop().toLowerCase(), fileExtension) == -1) {
        alert("Only formats are allowed : " + fileExtension.join(', '));
        return false;
    }
    var employee = new FormData();
    var MediaPath = $("#file9").get(0).files;
    var MediaId = $("#mId9").val();
    var vin = $("#Vin").val();
    var MediaType = $("#rId9").val();
    var ImageUrl = $("#img9").val();
    var JCNo = $('#jc').val();
    var RegistrationNo = $('#RG').val();
    var Vin = $('#vin').val();
    var ParentGroup = $('#prg').val();
    var DealerCd = $('#DC').val();
    var Recall = MediaType.includes("Recall-");
    if (Recall == true) {
        employee.append(vin + '_' + "RECALLBEFORE" + '_' + MediaPath[0], MediaPath[0]);
    }
    else {
        employee.append(vin + '_' + "RECALLAFTER" + '_' + MediaPath[0], MediaPath[0]);
    }

    var data = new FormData();
    //data.append("MediaPath", MediaPath);
    data.append("MediaId", MediaId);
    data.append("vin", vin);
    data.append("MediaType", MediaType);
    data.append("JCNo", JCNo);
    data.append("RegistrationNo", RegistrationNo);
    data.append("Vin", Vin);
    data.append("DealerCd", DealerCd);
    $.ajax({
        type: "POST",
        url: BaseUrl + "/Sync/SaveMultiPartImages",
        data: employee,//JSON.stringify(employee),
        contentType: false,
        processData: false,
        dataType: "json",
        success: function (response) {
            debugger;
            //response.RecallImageDetails[0].ImageUrl;
            console.log(response);
            console.log(response.RecallImageDetails[0].ImageUrl);
            var MediaPath = response.RecallImageDetails[0].ImageUrl;
            data.append("MediaPath", MediaPath)
            $.ajax({
                type: "POST",
                url: BaseUrl1 + "/Home/UpdateRecallMediaPath",
                data: data,//JSON.stringify(employee),
                contentType: false,
                processData: false,
                dataType: "json",
                success: function (response) {
                    if (response == 200) {
                        alert('File Uploaded successfully');
                    }
                },
            });
        },
    })
});

$('#file10').change(function (e) {
    debugger;
    var fileExtension = ['jpeg', 'jpg', 'png', 'gif', 'bmp'];
    if ($.inArray($(this).val().split('.').pop().toLowerCase(), fileExtension) == -1) {
        alert("Only formats are allowed : " + fileExtension.join(', '));
        return false;
    }
    var employee = new FormData();
    var MediaPath = $("#file10").get(0).files;
    var MediaId = $("#mId10").val();
    var vin = $("#Vin").val();
    var MediaType = $("#rId10").val();
    var ImageUrl = $("#img10").val();
    var JCNo = $('#jc').val();
    var RegistrationNo = $('#RG').val();
    var Vin = $('#vin').val();
    var ParentGroup = $('#prg').val();
    var DealerCd = $('#DC').val();
    var Recall = MediaType.includes("Recall-");
    if (Recall == true) {
        employee.append(vin + '_' + "RECALLBEFORE" + '_' + MediaPath[0], MediaPath[0]);
    }
    else {
        employee.append(vin + '_' + "RECALLAFTER" + '_' + MediaPath[0], MediaPath[0]);
    }

    var data = new FormData();
    //data.append("MediaPath", MediaPath);
    data.append("MediaId", MediaId);
    data.append("vin", vin);
    data.append("MediaType", MediaType);
    data.append("JCNo", JCNo);
    data.append("RegistrationNo", RegistrationNo);
    data.append("Vin", Vin);
    data.append("DealerCd", DealerCd);
    $.ajax({
        type: "POST",
        url: BaseUrl + "/Sync/SaveMultiPartImages",
        data: employee,//JSON.stringify(employee),
        contentType: false,
        processData: false,
        dataType: "json",
        success: function (response) {
            debugger;
            //response.RecallImageDetails[0].ImageUrl;
            console.log(response);
            console.log(response.RecallImageDetails[0].ImageUrl);
            var MediaPath = response.RecallImageDetails[0].ImageUrl;
            data.append("MediaPath", MediaPath)
            $.ajax({
                type: "POST",
                url: BaseUrl1 + "/Home/UpdateRecallMediaPath",
                data: data,//JSON.stringify(employee),
                contentType: false,
                processData: false,
                dataType: "json",
                success: function (response) {
                    if (response == 200) {
                        alert('File Uploaded successfully');
                    }
                },
            });
        },
    })
});

$('#file11').change(function (e) {
    debugger;
    var employee = new FormData();
    var MediaPath = $("#file11").get(0).files;
    var MediaId = $("#mId11").val();
    var vin = $("#Vin").val();
    var MediaType = $("#rId11").val();
    var ImageUrl = $("#img11").val();
    var JCNo = $('#jc').val();
    var RegistrationNo = $('#RG').val();
    var Vin = $('#vin').val();
    var ParentGroup = $('#prg').val();
    var DealerCd = $('#DC').val();
    var Recall = MediaType.includes("Recall-");
    if (Recall == true) {
        employee.append(vin + '_' + "RECALLBEFORE" + '_' + MediaPath[0], MediaPath[0]);
    }
    else {
        employee.append(vin + '_' + "RECALLAFTER" + '_' + MediaPath[0], MediaPath[0]);
    }

    var data = new FormData();
    //data.append("MediaPath", MediaPath);
    data.append("MediaId", MediaId);
    data.append("vin", vin);
    data.append("MediaType", MediaType);
    data.append("JCNo", JCNo);
    data.append("RegistrationNo", RegistrationNo);
    data.append("Vin", Vin);
    data.append("DealerCd", DealerCd);
    $.ajax({
        type: "POST",
        url: BaseUrl + "/Sync/SaveMultiPartImages",
        data: employee,//JSON.stringify(employee),
        contentType: false,
        processData: false,
        dataType: "json",
        success: function (response) {
            debugger;
            //response.RecallImageDetails[0].ImageUrl;
            console.log(response);
            console.log(response.RecallImageDetails[0].ImageUrl);
            var MediaPath = response.RecallImageDetails[0].ImageUrl;
            data.append("MediaPath", MediaPath)
            $.ajax({
                type: "POST",
                url: BaseUrl1 + "/Home/UpdateRecallMediaPath",
                data: data,//JSON.stringify(employee),
                contentType: false,
                processData: false,
                dataType: "json",
                success: function (response) {
                    if (response == 200) {
                        alert('File Uploaded successfully');
                    }
                },
            });
        },
    })
});

