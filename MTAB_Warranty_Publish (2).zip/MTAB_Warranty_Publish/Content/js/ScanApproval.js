﻿//var _RegNo = '';
//var _JcNo= '';

$(document).ready(function () {
    //$("#btnSearch").click();

    var userRole = $("#role").val();
    $('#btnRefresh').hide();
    objData = {};
    if (userRole == "RSM" || userRole == "ZSH") {

        objData.IsStatus = $('input[name="RdoBtn"]:checked').val();
        $("#loader").show();

        APIModule.Call('POST', BaseUrl1 + '/Home/ScanJCDetails', JSON.stringify(objData)).done(function (data) {

            var row = '';
            $("#warrantydetails").append(row);

            if (data != '') {
                var res = JSON.parse(data);
                if (res.result == 'success' && res.media != null) {
                    if (res.media.length > 0) {
                        resultCount = res.media.length;
                        $('#totalcount').text("Total: " + resultCount);
                        for (var i = 0; i < res.media.length; i++) {
                            row = $("<tr onClick='BindCelData_New(this);'>");
                            row.append($("<td style='text-align:right'>").text(res.media[i].ScanStatus == null ? '--' : res.media[i].ScanStatus));
                            row.append($("<td>").text(res.media[i].DealerMapCd));
                            row.append($("<td>").text(res.media[i].DealerCode));
                            row.append($("<td>").text(res.media[i].JobCardNo));
                            row.append($("<td>").text(res.media[i].ScanType));
                            row.append($("<td data-date-format='yy-mm-dd'>").text(res.media[i].OpenDate));
                            row.append($("<td>").text(res.media[i].RegNo));
                            row.append($("<td>").text(res.media[i].Vin == null ? '--' : res.media[i].Vin));
                            row.append($("<td>").text(res.media[i].CreatedBy));
                            row.append($("<td>").text(res.media[i].ParentGroup));
                            row.append($("<td>").text(res.media[i].LocCd));
                            row.append($("<td>").text(res.media[i].ScanUpdateBy));
                            row.append($("<td>").text(res.media[i].ScanUpdatedDate));
                            row.append($("<td>").text(res.media[i].TSMStatus));
                            row.append($("<td>").text(res.media[i].RSMStatus));
                            row.append($("<td>").text(res.media[i].ZSHStatus));
                            row.append($("<td>").text(res.media[i].LeastConfidence));
                            row.append($("<td>").text(res.media[i].MismatchCharacters));
                            row.append($("<td style='display:none;' class='ScanStatus'>").text(res.media[i].ScanStatus));
                            row.append($("<td style='display:none;' class='RSMStatus'>").text(res.media[i].RSMStatus));
                            row.append($("<td style='display:none;' class='ZSHStatus'>").text(res.media[i].ZSHStatus));
                            row.append("</tr>");
                            $("#warrantydetails").append(row);
                            //_RegNo = res.media[i].RegNo;
                            //_JcNo = res.media[i].JobCardNo;
                        }
                        $("#loader").hide();
                        var collection = $(".ScanStatus");
                        collection.each(function () {
                            let ZSHStatus = $(this).parent().children(".ZSHStatus").text().trim();
                            let RSMStatus = $(this).parent().children(".RSMStatus").text().trim();
                            if (userRole == "RSM") {
                                if (RSMStatus === "") {
                                    $(this).parent('tr').addClass('highlight-lightblue');
                                }
                                else {
                                    if ($(this).text() === 'Approved') {
                                        $(this).parent('tr').addClass('highlight-true');
                                    }
                                    if ($(this).text() === 'Pending') {
                                        $(this).parent('tr').addClass('highlight-Pending');
                                    }
                                    if ($(this).text() === 'Rejected') {
                                        $(this).parent('tr').addClass('highlight-Rejact');
                                    }
                                }
                            }
                            if (userRole == "ZSH") {
                                if (ZSHStatus === "") {
                                    $(this).parent('tr').addClass('highlight-lightblue');
                                }
                                else {
                                    if ($(this).text() === 'Approved') {
                                        $(this).parent('tr').addClass('highlight-true');
                                    }
                                    if ($(this).text() === 'Pending') {
                                        $(this).parent('tr').addClass('highlight-Pending');
                                    }
                                    if ($(this).text() === 'Rejected') {
                                        $(this).parent('tr').addClass('highlight-Rejact');
                                    }
                                }
                            }
                        });
                    }
                    else {
                        $("#loader").hide();
                        row = $("<tr>");
                        row.append($("<td colspan='18' align='center'>").text("No record found."));
                        $("#warrantydetails").append(row);
                        $(".tabMainSec").hide();
                        $("#btnShareEmail").hide();
                        $("#btndownload").hide();
                    }
                }
                else {
                    $("#loader").hide();
                    row = $("<tr>");
                    row.append($("<td colspan='18' align='center'>").text("No record found."));
                    $("#warrantydetails").append(row);
                    $(".tabMainSec").hide();
                    $("#btnShareEmail").hide();
                    $("#btndownload").hide();
                }
            }
            else {
                $("#loader").hide();
                row = $("<tr>");
                row.append($("<td colspan='18' align='center'>").text("No record found."));
                $("#warrantydetails").append(row);
                $(".tabMainSec").hide();
                $("#btnShareEmail").hide();
                $("#btndownload").hide();
            }
            objData = null;
        }).fail(function (jqXHR, status, error) {
            $("#loader").hide();
            ErrorLogger(jqXHR, status, error);
        });


    }




    $("#warrantydetails >tbody >tr").html('');
    var row = '';
    row = $("<tr>");
    //   row.append($("<td colspan='9' align='center'>").text("Data not found."));
    $("#warrantydetails").append(row);
    $("#videodownload").hide();

    var resultCount = 0;
    // GetDealerCode();
    $("#btndownloaddoc").hide();
    Image_Count = 0;
    links_url = [];
});
//Base Url of this application
var BaseUrl1 = window.location.origin;
//var BaseUrl1 = window.location.origin + "/MTabWarrantyMedia_QA";

$("#btneScasnxport").click(function () {
    //debugger;
    var employee = new Object();
    employee.JCNo = $("#txtJobCardNo").val();
    employee.RegistrationNo = $("#txtRegNo").val();
    employee.DealerCode = $("#txtDealerCode").val();
    employee.Vin = $("#txtVin").val();
    employee.RdoBtn = $('input[name="RdoBtn"]:checked').val();

    if (employee.JCNo == "" && employee.RegistrationNo == "" && employee.DealerCode == "" && employee.Vin == "" && employee.RdoBtn == undefined) {
        alert('Please fill at least one input field.');
        return false;
    }
    $.ajax({
        type: "POST",
        url: BaseUrl1 + "/Home/ExportScanApprovalExcelData",
        data: JSON.stringify(employee),
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (response) {

        },

    });
});

function myFunction() {
    alert("Dealer code is required.");
    end;
}

$("#btnSearch").on('click', function (event) {
    //debugger;
    var row = '';
    $("#videodownload").hide();
    $("#partialviewmediaRe .row").html('');
    $("#partialviewmediaRe .row").append(row);
    $("#partialviewbefore .row").html('');
    $("#partialviewbefore .row").append(row);
    $("#partialviewafter .row").html('');
    $("#partialviewafter .row").append(row);
    $("#btndownloaddoc").hide();

    $("#warrantydetails >tbody >tr").html('');
    $("#partialviewmediaRe .row").html('');
    $("#partialviewaudiomedia .row").html('');
    $("#partialviewbefore .row").html('');
    $("#partialviewafter .row").html('');
    $("#partialviewdefectmedia .row").html('');
    $('#totalcount').text('');
    GetMediaDetails_Recall(); // For Recall
});
function GetMediaDetails_Recall() {

    objData = {};
    var hasInput = false;
    //objData.IsStatus = $('input[name="RdoBtn"]:checked').val();
    $('.form-control').each(function () {
        if ($(this).val() !== "") {

            objData.JCNo = $("#txtJobCardNo").val();
            objData.RegistrationNo = $("#txtRegNo").val();
            objData.DealerMapCd = $("#txtDealerCode").val();
            objData.Vin = $("#txtVin").val();
            objData.IsStatus = $('input[name="RdoBtn"]:checked').val();
            objData.DealerZoneCode = $("#ZoneCode").val();
            objData.DealerRegionCode = $("#RegionCode").val();
            var userRole = $("#role").val();
            if (userRole == "TSM") {
                if (objData.DealerMapCd == "") {
                    myFunction();
                }
            }
            //hasInput = false;
            //if (objData.JCNo != "" || objData.RegistrationNo != "" || objData.DealerMapCd != "" || objData.Vin != "" || objData.IsStatus != undefined || objData.DealerZoneCode != "" || objData.DealerRegionCode != "") {
            hasInput = true;
            //}
        }
    });
    if (!hasInput) {
        alert('Please fill at least one input field.');
        $("#warrantydetails >tbody >tr").html('');
        var row = '';
        row = $("<tr>");
        //  row.append($("<td colspan='9' align='center'>").text("Data not found."));
        $("#warrantydetails").append(row);
        $(".tabMainSec").hide();
        $("#videodownload").hide();
        $("#btndownloaddoc").hide();
    }
    else {
        $("#loader").show();

        APIModule.Call('POST', BaseUrl1 + '/Home/ScanJCDetails', JSON.stringify(objData)).done(function (data) {

            var row = '';
            $("#warrantydetails").append(row);

            if (data != '') {
                var res = JSON.parse(data);
                if (res.result == 'success' && res.media != null) {
                    if (res.media.length > 0) {
                        resultCount = res.media.length;
                        $('#totalcount').text("Total: " + resultCount);
                        for (var i = 0; i < res.media.length; i++) {
                            row = $("<tr onClick='BindCelData_New(this);'>");
                            row.append($("<td style='text-align:right'>").text(res.media[i].ScanStatus == null ? '--' : res.media[i].ScanStatus));
                            row.append($("<td>").text(res.media[i].DealerMapCd));
                            row.append($("<td>").text(res.media[i].DealerCode));
                            row.append($("<td>").text(res.media[i].JobCardNo));
                            row.append($("<td>").text(res.media[i].ScanType));
                            row.append($("<td data-date-format='yy-mm-dd'>").text(res.media[i].OpenDate));
                            row.append($("<td>").text(res.media[i].RegNo));
                            row.append($("<td>").text(res.media[i].Vin == null ? '--' : res.media[i].Vin));
                            row.append($("<td>").text(res.media[i].CreatedBy));
                            row.append($("<td>").text(res.media[i].ParentGroup));
                            row.append($("<td>").text(res.media[i].LocCd));
                            row.append($("<td>").text(res.media[i].ScanUpdateBy));
                            row.append($("<td>").text(res.media[i].ScanUpdatedDate));
                            row.append($("<td>").text(res.media[i].TSMStatus));
                            row.append($("<td>").text(res.media[i].RSMStatus));
                            row.append($("<td>").text(res.media[i].ZSHStatus));
                            row.append($("<td>").text(res.media[i].LeastConfidence));
                            row.append($("<td>").text(res.media[i].MismatchCharacters));
                            row.append($("<td style='display:none;' class='ScanStatus'>").text(res.media[i].ScanStatus));
                            row.append($("<td style='display:none;' class='TSMStatus'>").text(res.media[i].TSMStatus));
                            row.append($("<td style='display:none;' class='RSMStatus'>").text(res.media[i].RSMStatus));
                            row.append($("<td style='display:none;' class='ZSHStatus'>").text(res.media[i].ZSHStatus));
                            row.append("</tr>");
                            $("#warrantydetails").append(row);
                            //_RegNo = res.media[i].RegNo;
                            //_JcNo = res.media[i].JobCardNo;
                        }
                        $("#loader").hide();
                        var collection = $(".ScanStatus");
                        collection.each(function () {
                            var userRole = $("#role").val();
                            let TSMStatus = $(this).parent().children(".TSMStatus").text().trim();
                            let RSMStatus = $(this).parent().children(".RSMStatus").text().trim();
                            let ZSHStatus = $(this).parent().children(".ZSHStatus").text().trim();
                            console.log("TSMStatus", TSMStatus);
                            console.log("RSMStatus", RSMStatus);
                            console.log("ZSHStatus", ZSHStatus);
                            if (userRole == "TSM") {
                                if (TSMStatus === "") {
                                    $(this).parent('tr').addClass('highlight-lightblue');
                                }
                                else {

                                    if ($(this).text() === 'Approved') {
                                        $(this).parent('tr').addClass('highlight-true');
                                    }
                                    if ($(this).text() === 'Pending') {
                                        $(this).parent('tr').addClass('highlight-Pending');
                                    }
                                    if ($(this).text() === 'Rejected') {
                                        $(this).parent('tr').addClass('highlight-Rejact');
                                    }
                                }

                            }
                            if (userRole == "RSM") {
                                if (RSMStatus === "") {
                                    $(this).parent('tr').addClass('highlight-lightblue');
                                }
                                else {

                                    if ($(this).text() === 'Approved') {
                                        $(this).parent('tr').addClass('highlight-true');
                                    }
                                    if ($(this).text() === 'Pending') {
                                        $(this).parent('tr').addClass('highlight-Pending');
                                    }
                                    if ($(this).text() === 'Rejected') {
                                        $(this).parent('tr').addClass('highlight-Rejact');
                                    }
                                }

                            }

                            if (userRole == "ZSH") {
                                if (ZSHStatus === "") {
                                    $(this).parent('tr').addClass('highlight-lightblue');
                                }
                                else {

                                    if ($(this).text() === 'Approved') {
                                        $(this).parent('tr').addClass('highlight-true');
                                    }
                                    if ($(this).text() === 'Pending') {
                                        $(this).parent('tr').addClass('highlight-Pending');
                                    }
                                    if ($(this).text() === 'Rejected') {
                                        $(this).parent('tr').addClass('highlight-Rejact');
                                    }
                                }

                            }


                        });

                    }
                    else {
                        $("#loader").hide();
                        row = $("<tr>");
                        row.append($("<td colspan='18' align='center'>").text("No record found."));
                        $("#warrantydetails").append(row);
                        $(".tabMainSec").hide();
                        $("#btnShareEmail").hide();
                        $("#btndownload").hide();
                    }
                }
                else {
                    $("#loader").hide();
                    row = $("<tr>");
                    row.append($("<td colspan='18' align='center'>").text("No record found."));
                    $("#warrantydetails").append(row);
                    $(".tabMainSec").hide();
                    $("#btnShareEmail").hide();
                    $("#btndownload").hide();
                }
            }
            else {
                $("#loader").hide();
                row = $("<tr>");
                row.append($("<td colspan='18' align='center'>").text("No record found."));
                $("#warrantydetails").append(row);
                $(".tabMainSec").hide();
                $("#btnShareEmail").hide();
                $("#btndownload").hide();
            }
            objData = null;
        }).fail(function (jqXHR, status, error) {
            $("#loader").hide();
            ErrorLogger(jqXHR, status, error);
        });
    }
}
var APIModule = (function () {
    var Call = function (RequestType, APIUrl, content) {
        return $.ajax({
            type: RequestType,
            url: APIUrl,
            data: content,
            contentType: "application/json; charset=utf-8",
            datatype: "json",
            async: "true",
            crossDomain: true
        });
    };
    function setHeader(xhr) {
        xhr.setRequestHeader('Access-Control-Allow-Origin', '*');
    }
    return {
        Call: Call
    }
})();
function ErrorLogger(jqXHR, status, error) {
    console.log(jqXHR, status, error);
}
function ClearControl() {
    $("#txtJobCardNo").val('');
    $("#txtRegNo").val('');
    $("#txtDealerCode").val('');
    $("#txtVin").val('');
    $("#RegionCode").val('');
    $("#ZoneCode").val('');
    $('input[name="RdoBtn"]').prop('checked', false);
}
function ClearMediaList() {
    // clear the jobcardlist, audio, image and vidio list
    $("#warrantydetails >tbody >tr").html('');
    var row = '';
    row = $("<tr>");
    var userRole = $("#role").val();
    if (userRole == "RSM" || userRole == "ZSH") {

        row.append($("<td colspan='18' align='center'>").text("Data not found please click on refresh button."));
    }
    else {
        row.append($("<td colspan='18' align='center'>").text("Data not found."));
    }
    $("#warrantydetails").append(row);
    $("#videodownload").hide();
    $("#partialviewmediaRe .row").html('');
    $("#partialviewaudiomedia .row").html('');
    $("#partialviewbefore .row").html('');
    $("#partialviewafter .row").html('');
    $("#partialviewdefectmedia .row").html('');
    $("#btnShareEmail").hide();
    $("#btndownload").hide();
    $('#totalcount').text('');
    $("#btndownloaddoc").hide();
    $(".tabMainSec").hide();
}
function BindCelData_New(x) {
    debugger;
    $(".tableFixHead tr").click(function () {
        links_url = [];
        Image_Count = 0;
        var collection = x.cells.item(18).innerHTML;
        if (collection == 'Rejected' || collection == 'Approved' || collection == 'Pending') {

            $(".tableFixHead tr").removeClass("highlighttbl-available");
            $(this).addClass("highlighttbl-available");
            $("#btnShareEmail").show();
            $("#btndownload").show();
            $(".tabMainSec").show();

            //for scrolling 
            //$("html, body").animate({ scrollTop: 300 }, "slow");
            //return false;
        }
        else if (collection == 'false') {
            $(".tableFixHead tr").removeClass("highlight-available");
            $(".tableFixHead tr").removeClass("highlight");
            $(this).addClass("highlight");
            $("#btnShareEmail").hide();
            $("#btndownload").hide();
            $(".tabMainSec").hide();
        }
    });
    BindMedia_New(x);
}
function BindMedia_New(tableCell) {
    $("#btnShareEmail").show();
    $("#btndownload").show();
    $(".tabMainSec").show();
    JobCardNo = tableCell.cells.item(3).innerHTML;
    RegNo = tableCell.cells.item(6).innerHTML;
    Vin = tableCell.cells.item(7).innerHTML;
    DealerCode = tableCell.cells.item(2).innerHTML;
    IsStatus = tableCell.cells.item(0).innerHTML;
    ParentGroup = tableCell.cells.item(8).innerHTML;
    LocCd = tableCell.cells.item(10).innerHTML;
    DealerMapCd = tableCell.cells.item(1).innerHTML;

    //_MediaType = $('input[name="optradio"]:checked').val();

    //switch (_MediaType) {
    //    case "OCAS":
    //        MediaType = 'ocas';
    //        GetJCWarrantyMedia_OCAS(JobCardNo, RegNo);
    //        break;
    //    case "PDI":
    //        MediaType = 'pdi';
    //        GetJCWarrantyMedia_PDI(JobCardNo, Vin);
    //        break;
    //}
    GetJCWarrantyMedia_Recall(JobCardNo, RegNo, Vin, DealerCode, IsStatus, ParentGroup, LocCd, DealerMapCd);
}

$("#after-tab").on("click", function () {
    debugger;
    APIModule.Call('POST', BaseUrl1 + '/Home/GetRecallMediaAfter', JSON.stringify(objData)).done(function (data) {

        if (data != '') {
            debugger;
            $("#partialviewAfter").show();
            $("#partialviewAfter").html(data);
        }

    });
});


function GetJCWarrantyMedia_Recall(JobCardNo, RegNo, Vin, DealerCode, IsStatus, ParentGroup, LocCd, DealerMapCd) {
    event.preventDefault();
    $("#partialviewmediaRe").show();
    $("#videodownload").hide();
    $("#partialviewmediaRe .row").html('');
    $("#partialviewdefectmedia .row").html('');
    $("#partialviewaudiomedia .row").html('');
    $("#partialviewbefore .row").html('');
    $("#partialviewafter .row").html('');
    $("#btndownloaddoc").hide();

    var hasInput = false;
    if (JobCardNo != '' && RegNo != '') {
        objData = {};
        objData.JCNo = JobCardNo;
        objData.RegistrationNo = RegNo;
        objData.Vin = Vin;
        objData.DealerMapCd = DealerCode;
        objData.IsStatus = IsStatus;
        objData.ParentGroup = ParentGroup;
        objData.LocCd = LocCd;
        objData.DealerMapCd1 = DealerMapCd;
        hasInput = true;
    }
    if (!hasInput) {
        alert('Recall media data not found.');
        $("#videodownload").hide();
        $("#partialviewmediaRe .row").html('');
        $("#partialviewaudiomedia .row").html('');
        $("#partialviewbefore .row").html('');
        $("#partialviewafter .row").html('');
        $("#partialviewdefectmedia .row").html('');
        $("#btndownloaddoc").hide();
    }
    else {
        APIModule.Call('POST', BaseUrl1 + '/Home/GetScanMedia', JSON.stringify(objData)).done(function (data) {
            debugger;
            //$("#btnSearch").click();
            if (data != '') {
                debugger;
                $("#partialviewmediaRe").show();
                $("#partialviewmediaRe").html(data);


            }
        });
    }
}
function GetdownloadUrl() {
    imgurl = '';
    for (var i = 0; i < links_url.length; i++) {
        imgurl += links_url[i] + ',';
    }
    links = imgurl;
}
function downloadAll(urls) {
    if (urls == '') {
        alert('No record found.');
    }
    else {
        var link = document.createElement('a');
        link.style.display = 'none';
        document.body.appendChild(link);
        for (var i = 0; i < urls.length; i++) {
            link.setAttribute('href', urls[i]);
            link.setAttribute('download', JobCardNo + '-' + 'media-files' + i);
            link.click();
        }
        document.body.removeChild(link);
    }
}
$(function () {
    $('#SendEmail').click(function (event) {
        var email = 'mukeshh.sinha@gmail.com';
        var subject = 'Test';
        var emailBody = 'Hi Sample,';
        var attach = links;
        document.location = "mailto:" + email + "?subject=" + subject + "&body=" + emailBody + "?attach=" + attach;
    });
});
function isNumber(evt) {
    evt = (evt) ? evt : window.event;
    var charCode = (evt.which) ? evt.which : evt.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
        return false;
    }
    return true;
}
function isAlphabet(evt) {
    evt = (evt) ? evt : window.event;
    var charCode = (evt.which) ? evt.which : evt.keyCode;
    if ((charCode > 64 && charCode < 91) || (charCode > 96 && charCode < 123) || (charCode == 8) || (charCode == 9) || (charCode == 32)) {
        return true;
    }
    return false;
}
$('#txtJobCardNo, #txtRegNo').keypress(function (e) {
    var regex = new RegExp("^[a-zA-Z0-9]+$");
    var str = String.fromCharCode(!e.charCode ? e.which : e.charCode);
    if (regex.test(str)) {
        return true;
    }
    e.preventDefault();
    return false;
});
$('#download-all').click(function (event) {
    event.preventDefault();
    $('.my-file').multiDownload();
});
$('#btnReset').click(function (event) {
    debugger;
    event.preventDefault();
    ClearControl();
    ClearMediaList();
    var userRole = $("#role").val();
    if (userRole == "RSM" || userRole == "ZSH") {
        $('#btnRefresh').show();
        $('#btnReset').hide();
    }

});
$('#btnRefresh').click(function () {
    debugger;
    location.reload();
    $('#btnReset').show();
});

function validateEmail(email) {
    var regex = /^([a-zA-Z0-9_.+-])+\@(([a-zA-Z0-9-])+\.)+([a-zA-Z0-9]{2,4})+$/;
    return regex.test(email);
}
$('#btnSendEmail').click(function (event) {
    debugger;
    var hasInput = false;
    JCEMail = {};

    hasInput = VailidateEmailInputs();
    if (hasInput && links_url.length > 0) {
        JCEMail.JCNo = JobCardNo;
        JCEMail.RegistrationNo = RegNo
        JCEMail.ToAddress = $('#txtToEmail').val();
        JCEMail.CCAddress = $('#txtCcEmail').val();

        if (_MediaType === 'OCAS')
            JCEMail.Subject = 'Media File of JobCard No - ' + JobCardNo + ' & RegNo - ' + RegNo;
        else
            JCEMail.Subject = 'Media File of JobCard No - ' + JobCardNo + ' & Vin - ' + Vin;

        JCEMail.MediaAttachment = links_url;
        APIModule.Call('POST', BaseUrl1 + '/Home/SendEmail', JSON.stringify(JCEMail)).done(function (response) {

            if (response != '') {
                if (response.result == 'failure') {
                    $('#myModal').modal('hide');
                    ClearEmailControl();
                }
                else if (response.result == 'success') {
                    $('#myModal').modal('hide');
                    ClearEmailControl();
                }
            }
            else {

            }
        }).fail(function (jqXHR, status, error) {
            ErrorLogger(jqXHR, status, error);
        });
    }
});
function VailidateEmailInputs() {
    var hasInput = false;
    if (validateEmail($('#txtToEmail').val()) && $('#txtToEmail').val != '') {
        hasInput = true;
    }
    else if ($('#txtCcEmail').val != '' && validateEmail($('#txtCcEmail').val())) {
        hasInput = true;
    }
    else if ($('#txtToEmail').val == '') {

        alert("Please fill the email id.");
        hasInput = false;
    }
    else {
        alert("Please enter vailid email id.");
        hasInput = false;
    }
    return hasInput;
}
function ClearEmailControl() {
    $("#txtToEmail").val('');
    $("#txtCcEmail").val('');
}
document.addEventListener('play', function (e) {
    var audios = document.getElementsByTagName('audio');
    for (var i = 0, len = audios.length; i < len; i++) {
        if (audios[i] != e.target) {
            audios[i].pause();
        }
    }
}, true);
//    $("#DDLRecall").change(function (event) {
//        debugger;
//       alert($('option:selected', this).text());
//        alert($('#DDLRecall option:selected').text());

//});
function jsFunction(value) {

    // alert(value);
    if (value == "NG") {
        $("#ApproveBtn").hide();
    }
    else if (value == "OK") {
        $("#ApproveBtn").show();
    }


}