﻿//var _RegNo = '';
//var _JcNo= '';

$(document).ready(function () {
    $("#warrantydetails >tbody >tr").html('');
    var row = '';
    row = $("<tr>");
    row.append($("<td colspan='9' align='center'>").text("Data not found."));
    $("#warrantydetails").append(row);
    $("#videodownload").hide();

    var resultCount = 0;
    GetDealerCode();
    $("#btndownloaddoc").hide();
    Image_Count = 0;
    links_url = [];
});
//Base Url of this application
var BaseUrl = window.location.origin;
//var BaseUrl = window.location.origin + "/MTabWarrantyMedia";

$("input[name='optradio']").change(function () {
    if ($('input[name="optradio"]:checked').val() === 'OCAS') {
        event.preventDefault();
        ClearControl();
        ClearMediaList();
        $(".regno").show();
        GetDealerCode();

    }
    else {
        event.preventDefault();
        ClearControl();
        ClearMediaList();
        $(".regno").hide();
        GetPDIDealerCode();
    }
});

$("#btnSearch").on('click', function (event) {
    var row = '';
    $("#videodownload").hide();
    $("#partialviewmedia .row").html('');
    $("#partialviewmedia .row").append(row);
    $("#partialviewbefore .row").html('');
    $("#partialviewbefore .row").append(row);
    $("#partialviewafter .row").html('');
    $("#partialviewafter .row").append(row);
    $("#btndownloaddoc").hide();
    // $(".tabMainSec").hide();

    _MediaType = $('input[name="optradio"]:checked').val();

    switch (_MediaType) {
        case "OCAS":
            $("#warrantydetails >tbody >tr").html('');
            $("#partialviewmedia .row").html('');
            $("#partialviewaudiomedia .row").html('');
            $("#partialviewbefore .row").html('');
            $("#partialviewafter .row").html('');
            $("#partialviewdefectmedia .row").html('');
            $('#totalcount').text('');
            GetMediaDetails_OCAS();
            break;
        case "PDI":
            $("#warrantydetails >tbody >tr").html('');
            $("#partialviewmedia .row").html('');
            $("#partialviewaudiomedia .row").html('');
            $("#partialviewbefore .row").html('');
            $("#partialviewafter .row").html('');
            $("#partialviewdefectmedia .row").html('');
            //row = $("<tr>");
            //row.append($("<td colspan='9' align='center'>").text("PDI media data not found."));
            //$("#warrantydetails").append(row);
            $('#totalcount').text('');
            GetMediaDetails_PDI();
            break;
    }
});

function GetMediaDetails_OCAS() {
    objData = {};
    var hasInput = false;
    $('.form-control').each(function () {
        if ($(this).val() !== "") {

            objData.JCNo = $("#txtJobCardNo").val();
            objData.RegistrationNo = $("#txtRegNo").val();
            objData.DealerMapCd = $("#txtDealerCode").val();
            objData.Vin = $("#txtVin").val();
            hasInput = true;
        }
    });

    if (!hasInput) {
        alert('Please fill at least one input field.');
        $("#warrantydetails >tbody >tr").html('');
        var row = '';
        row = $("<tr>");
        row.append($("<td colspan='9' align='center'>").text("Data not found."));
        $("#warrantydetails").append(row);
        $(".tabMainSec").hide();
        $("#videodownload").hide();
        $("#btndownloaddoc").hide();
    }
    else {
        $("#loader").show();

        APIModule.Call('POST', BaseUrl + '/Home/MediaDetails_New', JSON.stringify(objData)).done(function (data) {
            var row = '';
            $("#warrantydetails").append(row);
            if (data != '') {
                var res = JSON.parse(data);
                if (res.result == 'success' && res.media != null) {
                    if (res.media.length > 0) {
                        resultCount = res.media.length;
                        $('#totalcount').text("Total: " + resultCount);
                        for (var i = 0; i < res.media.length; i++) {
                            row = $("<tr onClick='BindCelData_New(this);'>");
                            row.append($("<td>").text(res.media[i].DealerZone == null ? '--' : res.media[i].DealerZone));
                            row.append($("<td>").text(res.media[i].DealerRegion == null ? '--' : res.media[i].DealerRegion));
                            row.append($("<td>").text(res.media[i].DealerCode));
                            row.append($("<td>").text(res.media[i].JobCardNo));
                            row.append($("<td data-date-format='yy-mm-dd'>").text(res.media[i].OpenDate));
                            row.append($("<td>").text(res.media[i].RegNo));
                            row.append($("<td>").text(res.media[i].Vin == null ? '--' : res.media[i].Vin));
                            row.append($("<td>").text(res.media[i].VersionUsed == null || res.media[i].VersionUsed == '' ? '--' : res.media[i].VersionUsed));
                            row.append($("<td>").text(res.media[i].CreatedBy));
                            row.append($("<td style='display:none;' class='ismedia'>").text(res.media[i].IsMediaFile));
                            row.append("</tr>");
                            $("#warrantydetails").append(row);
                            //_RegNo = res.media[i].RegNo;
                            //_JcNo = res.media[i].JobCardNo;
                        }
                        $("#loader").hide();
                        var collection = $(".ismedia");
                        collection.each(function () {
                            if ($(this).text() == 'true') {
                                $(this).parent('tr').addClass('highlight-true');
                            }
                        });
                    }
                    else {
                        $("#loader").hide();
                        row = $("<tr>");
                        row.append($("<td colspan='9' align='center'>").text("No record found."));
                        $("#warrantydetails").append(row);
                        $(".tabMainSec").hide();
                        $("#btnShareEmail").hide();
                        $("#btndownload").hide();
                    }
                }
                else {
                    $("#loader").hide();
                    row = $("<tr>");
                    row.append($("<td colspan='9' align='center'>").text("No record found."));
                    $("#warrantydetails").append(row);
                    $(".tabMainSec").hide();
                    $("#btnShareEmail").hide();
                    $("#btndownload").hide();
                }
            }
            else {
                $("#loader").hide();
                row = $("<tr>");
                row.append($("<td colspan='9' align='center'>").text("No record found."));
                $("#warrantydetails").append(row);
                $(".tabMainSec").hide();
                $("#btnShareEmail").hide();
                $("#btndownload").hide();
            }
            objData = null;
        }).fail(function (jqXHR, status, error) {
            $("#loader").hide();
            ErrorLogger(jqXHR, status, error);
        });
    }
}

function GetMediaDetails_PDI() {

    objData = {};
    var hasInput = false;
    $('.form-control').each(function () {
        if ($(this).val() !== "") {

            objData.JCNo = $("#txtJobCardNo").val();
            objData.DealerMapCd = $("#txtDealerCode").val();
            objData.Vin = $("#txtVin").val();
            hasInput = true;
        }
    });

    if (!hasInput) {
        alert('Please fill at least one input field.');
        $("#warrantydetails >tbody >tr").html('');
        var row = '';
        row = $("<tr>");
        row.append($("<td colspan='9' align='center'>").text("Data not found."));
        $("#warrantydetails").append(row);
        $("#videodownload").hide();
        $("#btndownloaddoc").hide();
    }
    else {
        $("#loader").show();
        APIModule.Call('POST', BaseUrl + '/Home/PDIMediaDetails', JSON.stringify(objData)).done(function (data) {
            var row = '';
            $("#warrantydetails").append(row);
            if (data != '') {
                var res = JSON.parse(data);
                if (res.result == 'success' && res.media != null) {
                    if (res.media.length > 0) {
                        resultCount = res.media.length;
                        $('#totalcount').text("Total: " + resultCount);
                        for (var i = 0; i < res.media.length; i++) {
                            row = $("<tr onClick='BindCelData_New(this);'>");
                            row.append($("<td>").text(res.media[i].DealerZone == null ? '--' : res.media[i].DealerZone));
                            row.append($("<td>").text(res.media[i].DealerRegion == null ? '--' : res.media[i].DealerRegion));
                            row.append($("<td>").text(res.media[i].DealerCode));
                            row.append($("<td>").text(res.media[i].JobCardNo));
                            row.append($("<td data-date-format='yy-mm-dd'>").text(res.media[i].OpenDate));
                            row.append($("<td>").text(res.media[i].RegNo == null ? '--' : res.media[i].RegNo));
                            row.append($("<td>").text(res.media[i].Vin == null ? '--' : res.media[i].Vin));
                            row.append($("<td>").text(res.media[i].VersionUsed == null || res.media[i].VersionUsed == '' ? '--' : res.media[i].VersionUsed));
                            row.append($("<td>").text(res.media[i].CreatedBy));
                            row.append($("<td style='display:none;' class='ismedia'>").text(res.media[i].IsMediaFile));
                            row.append("</tr>");
                            $("#warrantydetails").append(row);
                        }
                        $("#loader").hide();
                        var collection = $(".ismedia");
                        collection.each(function () {
                            if ($(this).text() == 'true') {
                                $(this).parent('tr').addClass('highlight-true');
                            }
                        });
                    }
                    else {
                        $("#loader").hide();
                        row = $("<tr>");
                        row.append($("<td colspan='9' align='center'>").text("No record found."));
                        $("#warrantydetails").append(row);
                    }
                }
                else {
                    $("#loader").hide();
                    row = $("<tr>");
                    row.append($("<td colspan='9' align='center'>").text("No record found."));
                    $("#warrantydetails").append(row);
                }
            }
            else {
                $("#loader").hide();
                row = $("<tr>");
                row.append($("<td colspan='9' align='center'>").text("No record found."));
                $("#warrantydetails").append(row);
            }
            objData = null;
        }).fail(function (jqXHR, status, error) {
            $("#loader").hide();
            ErrorLogger(jqXHR, status, error);
        });
    }
}

var APIModule = (function () {
    var Call = function (RequestType, APIUrl, content) {
        return $.ajax({
            type: RequestType,
            url: APIUrl,
            data: content,
            contentType: "application/json; charset=utf-8",
            datatype: "json",
            async: "true",
            crossDomain: true
        });
    };
    function setHeader(xhr) {
        xhr.setRequestHeader('Access-Control-Allow-Origin', '*');
    }
    return {
        Call: Call
    }
})();
function ErrorLogger(jqXHR, status, error) {
    console.log(jqXHR, status, error);
}
function ClearControl() {
    $("#txtJobCardNo").val('');
    $("#txtRegNo").val('');
    $("#txtDealerCode").val('');
    $("#txtVin").val('');
}
function ClearMediaList() {
    // clear the jobcardlist, audio, image and vidio list
    $("#warrantydetails >tbody >tr").html('');
    var row = '';
    row = $("<tr>");
    row.append($("<td colspan='9' align='center'>").text("Data not found."));
    $("#warrantydetails").append(row);
    $("#videodownload").hide();
    $("#partialviewmedia .row").html('');
    $("#partialviewaudiomedia .row").html('');
    $("#partialviewbefore .row").html('');
    $("#partialviewafter .row").html('');
    $("#partialviewdefectmedia .row").html('');
    $("#btnShareEmail").hide();
    $("#btndownload").hide();
    $('#totalcount').text('');
    $("#btndownloaddoc").hide();
    $(".tabMainSec").hide();
}


function BindCelData_New(x) {
    debugger;
    $(".tableFixHead tr").click(function () {
        links_url = [];
        Image_Count = 0;
        var collection = x.cells.item(9).innerHTML;
        if (collection == 'true') {        
            $(".tableFixHead tr").removeClass("highlight-available");
            $(this).addClass("highlight-available");
            $("#btnShareEmail").show();
            $("#btndownload").show();
            $(".tabMainSec").show();
            //for scrolling 
            //$("html, body").animate({ scrollTop: 300 }, "slow");
            //return false;
        }
        else if (collection == 'false') {        
            $(".tableFixHead tr").removeClass("highlight-available");
            $(".tableFixHead tr").removeClass("highlight");
            $(this).addClass("highlight");
            $("#btnShareEmail").hide();
            $("#btndownload").hide();
            $(".tabMainSec").hide();
        }
    });
    BindMedia_New(x);
}
function BindMedia_New(tableCell) {
    $("#btnShareEmail").show();
    $("#btndownload").show();
    $(".tabMainSec").show();
    JobCardNo = tableCell.cells.item(3).innerHTML;
    RegNo = tableCell.cells.item(5).innerHTML;
    Vin = tableCell.cells.item(6).innerHTML;

    _MediaType = $('input[name="optradio"]:checked').val();

    switch (_MediaType) {
        case "OCAS":
            MediaType = 'ocas';
            GetJCWarrantyMedia_OCAS(JobCardNo, RegNo);
            break;
        case "PDI":
            MediaType = 'pdi';
            GetJCWarrantyMedia_PDI(JobCardNo, Vin);
            break;
    }
}
function GetJCWarrantyMedia_OCAS(JobCardNo, RegNo) {
    event.preventDefault();
    $("#partialviewmedia").show();
    $("#videodownload").hide();
    $("#partialviewmedia .row").html('');
    $("#partialviewdefectmedia .row").html('');
    $("#partialviewaudiomedia .row").html('');
    $("#partialviewbefore .row").html('');
    $("#partialviewafter .row").html('');
    $("#btndownloaddoc").hide();

    var hasInput = false;
    if (JobCardNo != '' && RegNo != '') {
        objData = {};
        objData.JCNo = JobCardNo;
        objData.RegistrationNo = RegNo;
        hasInput = true;
    }
    if (!hasInput) {
        alert('OCAS media data not found.');
        $("#videodownload").hide();
        $("#partialviewmedia .row").html('');
        $("#partialviewaudiomedia .row").html('');
        $("#partialviewbefore .row").html('');
        $("#partialviewafter .row").html('');
        $("#partialviewdefectmedia .row").html('');
        $("#btndownloaddoc").hide();
    }
    else {
        APIModule.Call('POST', BaseUrl + '/Home/GetJCWarrantyMedia', JSON.stringify(objData)).done(function (data) {

            if (data != '') {
                var res = JSON.parse(data);
                var row = '';
                var row1 = '';
                if (res.result == 'success' && res.media != null && res.media[0].MediaDetails != null && res.media[0].MediaDetails.length > 0) {

                    $("#partialviewmedia .row").html('');
                    $("#partialviewmedia .row").append(row);
                    $("#partialviewaudiomedia .row").html('');
                    $("#partialviewaudiomedia .row").append(row1);


                    for (var i = 0; i < res.media[0].MediaDetails.length; i++) {

                        var ext = res.media[0].MediaDetails[i].MediaPath.split('.').pop();
                        if (ext != '' && ext == 'mp4' && res.media[0].MediaDetails[i].MediaType == 'NULL') {
                            if (res.media[0].MediaDetails[i].MediaType != '' && res.media[0].MediaDetails[i].MediaType != null) {
                                $('#mediatype').text(res.media[0].MediaDetails[i].MediaType);
                            }
                            else {
                                //$('#mediatype').text('Standard Video');
                            }
                            $('#filename').text(res.media[0].MediaDetails[i].FileName.split('$')[0].split('.')[0].replace("/", ""));
                            $("#videodownload").show();
                            $("#video_url_mtab").attr("src", res.media[0].MediaDetails[i].MediaPath.replace("http://104.211.200.64/", "/"));
                            $("#video_url").attr("href", res.media[0].MediaDetails[i].MediaPath.replace("http://104.211.200.64/", "/"));
                            $("#video_url").attr("download", JobCardNo + '-' + 'media-files-' + i);
                        }
                        else if (ext != '' && ext == 'mp4' && res.media[0].MediaDetails[i].MediaType == 'OCAS Video') {
                            if (res.media[0].MediaDetails[i].MediaType != '' && res.media[0].MediaDetails[i].MediaType != null) {
                                $('#mediatype').text(res.media[0].MediaDetails[i].MediaType);
                            }
                            else {
                                //$('#mediatype').text('Standard Video');
                            }
                            $('#filename').text(res.media[0].MediaDetails[i].FileName.split('$')[0].split('.')[0].replace("/", ""));
                            $("#videodownload").show();
                            $("#video_url_mtab").attr("src", res.media[0].MediaDetails[i].MediaPath.replace("http://104.211.200.64/", "/"));
                            $("#video_url").attr("href", res.media[0].MediaDetails[i].MediaPath.replace("http://104.211.200.64/", "/"));
                            $("#video_url").attr("download", JobCardNo + '-' + 'media-files-' + i);
                        }
                        else if (ext != '' && ext == 'mp4' && res.media[0].MediaDetails[i].MediaType == 'Standard Video') {
                            row1 = $("<div class='col-sm-3 text-center'>");
                            if (res.media[0].MediaDetails[i].MediaType != '' && res.media[0].MediaDetails[i].MediaType != null && res.media[0].MediaDetails[i].MediaType != 'NULL') {
                                row1.append($("<span class='text-center'><strong>" + res.media[0].MediaDetails[i].MediaType + "</strong></span></br>"));
                            }
                            else {
                                row1.append($("<span class='text-center'></span></br>"));
                            }
                            row1.append($("<span style='font-size:x-small;'>" + res.media[0].MediaDetails[i].FileName.split('$')[0].split('.')[0].replace("/", "") + "</span>"));
                            //row1.append($("<a href= " + BaseUrl + "/Content/img/video-play-icon.png data-toggle='lightbox' data-gallery='gallery' download=" + JobCardNo + '-' + 'media-files-' + i + " target='_self'><span class='popup-thumnail'><img src=" + BaseUrl + "/Content/img/video-play-icon.png class='img-fluid rounded'></span><a href='" + res.media[0].MediaDetails[i].MediaPath.replace("http://104.211.200.64/", "/") + "'  download=" + JobCardNo + '-' + 'media-files-' + i + " target='_self' class='fancydownload'>Download</a></a>"));
							row1.append($("<a href='" + res.media[0].MediaDetails[i].MediaPath.replace("http://104.211.200.64/", "/") + "'><span class='popup-thumnail'><img src=" + BaseUrl + "/Content/img/video-play-icon.png class='img-fluid rounded'></span><a href='" + res.media[0].MediaDetails[i].MediaPath.replace("http://104.211.200.64/", "/") + "'  download=" + JobCardNo + '-' + 'media-files-' + i + " target='_self' class='fancydownload'>Download</a></a>"));
                            row1.append("</div>");
                        }
                        else if (ext != '' && ext == 'mp4' && res.media[0].MediaDetails[i].MediaType == 'Additional Video') {
                            row1 = $("<div class='col-sm-3 text-center'>");
                            if (res.media[0].MediaDetails[i].MediaType != '' && res.media[0].MediaDetails[i].MediaType != null && res.media[0].MediaDetails[i].MediaType != 'NULL') {
                                row1.append($("<span class='text-center'><strong>" + res.media[0].MediaDetails[i].MediaType + "</strong></span></br>"));
                            }
                            else {
                                row1.append($("<span class='text-center'></span></br>"));
                            }
                            row1.append($("<span style='font-size:x-small;'>" + res.media[0].MediaDetails[i].FileName.split('$')[0].split('.')[0].replace("/", "") + "</span>"));
                            //row1.append($("<a href= " + BaseUrl + "/Content/img/video-play-icon.png data-toggle='lightbox' data-gallery='gallery' download=" + JobCardNo + '-' + 'media-files-' + i + " target='_self'><span class='popup-thumnail'><img src=" + BaseUrl + "/Content/img/video-play-icon.png class='img-fluid rounded'></span><a href='" + res.media[0].MediaDetails[i].MediaPath.replace("http://104.211.200.64/", "/") + "'  download=" + JobCardNo + '-' + 'media-files-' + i + " target='_self' class='fancydownload'>Download</a></a>"));
							row1.append($("<a href='" + res.media[0].MediaDetails[i].MediaPath.replace("http://104.211.200.64/", "/") + "'><span class='popup-thumnail'><img src=" + BaseUrl + "/Content/img/video-play-icon.png class='img-fluid rounded'></span><a href='" + res.media[0].MediaDetails[i].MediaPath.replace("http://104.211.200.64/", "/") + "'  download=" + JobCardNo + '-' + 'media-files-' + i + " target='_self' class='fancydownload'>Download</a></a>"));
                            row1.append("</div>");
                        }
                        else if (ext != '' && ext == 'jpg' || ext == 'jpeg' && (!res.media[0].MediaDetails[i].MediaType.includes('Recall'))) {
                            row1 = $("<div class='col-sm-3 text-center'>");
                            if (res.media[0].MediaDetails[i].MediaType != '' && res.media[0].MediaDetails[i].MediaType != null && res.media[0].MediaDetails[i].MediaType != 'NULL' || res.media[0].MediaDetails[i].MediaType == "NULL" && (!res.media[0].MediaDetails[i].MediaType.includes('Recall'))) {
                                row1.append($("<span class='text-center'><strong>" + res.media[0].MediaDetails[i].MediaType + "</strong></span></br>"));
                                
                                row1.append($("<span style='font-size:x-small;'>" + res.media[0].MediaDetails[i].FileName.split('$')[0].split('.')[0].replace("/", "") + "</span>"));
                                row1.append($("<a href=" + res.media[0].MediaDetails[i].MediaPath.replace("http://104.211.200.64/", "/") + " data-toggle='lightbox' data-gallery='gallery' download=" + JobCardNo + '-' + 'media-files-' + i + " target='_self'><span class='popup-thumnail'><img src=" + res.media[0].MediaDetails[i].MediaPath.replace("http://104.211.200.64/", "/") + " class='img-fluid rounded'></span><a href='" + res.media[0].MediaDetails[i].MediaPath.replace("http://104.211.200.64/", "/") + "'  download=" + JobCardNo + '-' + 'media-files-' + i + " target='_self' class='fancydownload'>Download</a></a>"));
                                row1.append("</div>");
                            }
                            else {
                                row1.append($("<span class='text-center'></span></br>"));
                            }
                            //row1.append($("<span style='font-size:x-small;'>" + res.media[0].MediaDetails[i].FileName.split('$')[0].split('.')[0].replace("/", "") + "</span>"));
                            //row1.append($("<a href=" + res.media[0].MediaDetails[i].MediaPath.replace("http://104.211.200.64/", "/") + " data-toggle='lightbox' data-gallery='gallery' download=" + JobCardNo + '-' + 'media-files-' + i + " target='_self'><span class='popup-thumnail'><img src=" + res.media[0].MediaDetails[i].MediaPath.replace("http://104.211.200.64/", "/") + " class='img-fluid rounded'></span><a href='" + res.media[0].MediaDetails[i].MediaPath.replace("http://104.211.200.64/", "/") + "'  download=" + JobCardNo + '-' + 'media-files-' + i + " target='_self' class='fancydownload'>Download</a></a>"));
                            //row1.append("</div>");                         
                        }
                        else if (ext != '' && ext == 'wav') {
                            row = $("<div class='col-sm-4 text-center'>");
                            //if (res.media[0].MediaDetails[i].MediaType != '' && res.media[0].MediaDetails[i].MediaType != null && res.media[0].MediaDetails[i].MediaType != 'NULL' ) {
                            //    row.append($("<span class='text-center'><strong>Smart Talk Media</strong></span></br>"));
                            //}
                            //else
                            //{
                            //    row.append($("<span class='text-center'></span></br>"));
                            //}
                            row.append($("<span style='font-size:x-small;'>" + res.media[0].MediaDetails[i].FileName.split('$')[0].split('.')[0].replace("/", "") + "</span>"));
                            row.append($("<div class='audio_bg'><audio controls class='audio_width'><source src=" + res.media[0].MediaDetails[i].MediaPath.replace("http://104.211.200.64/", "/") + "  type='audio/ogg'><source src=" + res.media[0].MediaDetails[i].MediaPath.replace("http://104.211.200.64/", "/") + "  type='audio/mpeg'></audio> </div>"));
                            row.append($("<a href=" + res.media[0].MediaDetails[i].MediaPath.replace("http://104.211.200.64/", "/") + "  download=" + JobCardNo + '-' + 'media-files-' + i + " target='_self' class='btn btn-dark btn-block'>Download</a><br/>"));
                            row.append("</div>");
                        }
                        $("#partialviewmedia .row").append(row);
                        $("#partialviewaudiomedia .row").append(row1);

                        links_url[i] = res.media[0].MediaDetails[i].MediaPath.replace("http://104.211.200.64/", "/");
                        Image_Count = i;
                    }
                    GetdownloadUrl();
                }
                else {

                    $('.alertmsg').text('Media data not found.');
                    $("#alert-popup").show();
                    setTimeout(function () {
                        $('#alert-popup').fadeOut('fast');
                    }, 1000);
                }
            }
            else {
                $('.alertmsg').text('Media data not found.');
                $("#alert-popup").show();
                setTimeout(function () {
                    $('#alert-popup').fadeOut('fast');
                }, 1000);
                //$(".tabMainSec").hide();
            }
            objData = null;
        }).fail(function (jqXHR, status, error) {
            ErrorLogger(jqXHR, status, error);

        });

        APIModule.Call('POST', BaseUrl + '/Home/GetCQImageDetailsBefore', JSON.stringify(objData)).done(function (data) {

            if (data != '') {
                var res = data;
                var row = '';
                var row1 = '';
                var Model1 = '';

                if (res.result != null && res.message == 'Success') {

                    $("#partialviewbefore .row").html('');
                    $("#partialviewbefore .row").append(row1);
                    $("#partialviewbefore .Popup-model-collection").html('');
                    $("#partialviewbefore .Popup-model-collection").append(Model1);

                    for (var i = 0; i < res.result.length; i++) {

                        row1 = $("<div class='col-sm-3 text-center'>");
                        if (res.result[i].filename != '' && res.result[i].filename != null && res.result[i].filename != 'NULL' && res.result[i].ImageDetails_AnnotatedImagePath != '' && res.result[i].ImageDetails_AnnotatedImagePath != null && res.result[i].ImageDetails_AnnotatedImagePath != 'NULL' && res.result[i].ImageDetails_RawImagePath != '' && res.result[i].ImageDetails_RawImagePath != null && res.result[i].ImageDetails_RawImagePath != 'NULL') {
                            row1.append($("<span class='text-center'><strong>" + res.result[i].filename + "</strong></span></br>"));
                            //row1.append($("<span style='font-size:x-small;'>" + res.result[i].filename.split('$')[0].split('.')[0].replace("/", "") + "</span>"));
                            row1.append($("<a href='#ocas-popup-Before" + i + "' data-toggle='modal'> <span class='popup-thumnail'><img src='" + res.result[i].ImageDetails_AnnotatedImagePath + "' class='img-fluid rounded'></span> </a>"));
                            //row1.append($("<a href=" + res.result[i].ImageDetails_AnnotatedImagePath + " download=" + JobCardNo + '-' + 'media-files-' + i + " target='_self' class='fancydownload'>Download</a>"));                       
                            row1.append("</div>");

                            Model1 = $("<div class='modal fade ocas_modal' id='ocas-popup-Before" + i + "' tabindex='-1' role='dialog' aria-labelledby='exampleModalLabel' aria-hidden='true'>" +
                                "<div class='modal-dialog' role='document'>" +
                                "<div class='modal-content'>" +
                                "<div class='modal-body'>" +
                                "<a class='close' data-dismiss='modal'><img src='Content/img/popup-cross.png' alt=''></a>" +
                                "<div class='image_wrapper'>" +
                                "<div class='img_block'>" +
                                "<a href='" + res.result[i].ImageDetails_RawImagePath + "' data-fancybox='images'>" +
                                "<img src='" + res.result[i].ImageDetails_RawImagePath + "' alt=''>" +
                                "</a>" +
                                "<div class='download_img'>" +
                                //"<a href='" + res.result[i].ImageDetails_RawImagePath.replace("https://customerapproval.marutisuzuki.com/", "/") + "' download='" + JobCardNo + "-media-files-" + i + "' target='_self' class='fancydownload'>Download</a>" +
                                "<a href='" + res.result[i].ImageDetails_RawImagePath + "' download='" + JobCardNo + "-media-files-" + i + "' target='_blank'>Download</a>" +
                                "</div>	" +
                                "</div>" +
                                "<div class='img_block'>" +
                                "<a href='" + res.result[i].ImageDetails_AnnotatedImagePath + "' data-fancybox='images'>" +
                                "<img src='" + res.result[i].ImageDetails_AnnotatedImagePath + "' alt=''>" +
                                "</a>" +
                                "<div class='download_img'>" +
                                "<a href='" + res.result[i].ImageDetails_AnnotatedImagePath + "' download='" + JobCardNo + "-annoted-media-files-" + i + "' target='_blank'>Download</a>" +
                                "</div>" +
                                "</div>" +
                                "</div>" +
                                "</div>" +
                                "</div>" +
                                "</div>" +
                                "</div>");

                        }
                        else {
                            row1.append($("<span class='text-center'></span></br>"));
                        }

                        $("#partialviewbefore .row").append(row1);
                        $("#partialviewbefore .Popup-model-collection").append(Model1);

                        Image_Count++;
                        links_url[Image_Count] = res.result[i].ImageDetails_RawImagePath;
                        Image_Count++
                        links_url[Image_Count] = res.result[i].ImageDetails_AnnotatedImagePath;
                    }
                    GetdownloadUrl();
                }
                else {

                    //$('.alertmsg').text('Media data not found.');
                    //$("#alert-popup").show();
                    //setTimeout(function () {
                    //    $('#alert-popup').fadeOut('fast');
                    //}, 1000);
                }
            }
            else {
                $('.alertmsg').text('Media data not found.');
                $("#alert-popup").show();
                setTimeout(function () {
                    $('#alert-popup').fadeOut('fast');
                }, 1000);
            }
            objData = null;
        }).fail(function (jqXHR, status, error) {
            ErrorLogger(jqXHR, status, error);
        });

        APIModule.Call('POST', BaseUrl + '/Home/GetCQImageDetailsAfter', JSON.stringify(objData)).done(function (data_after) {

            if (data_after != '') {
                var res = data_after;
                //var row = '';
                var row_after = '';
                var Model_after = '';

                if (res.result != null && res.message == 'Success') {

                    $("#partialviewafter .row").html('');
                    $("#partialviewafter .row").append(row_after);
                    $("#partialviewafter .Popup-model-collection").html('');
                    $("#partialviewafter .Popup-model-collection").append(Model_after);

                    for (var i = 0; i < res.result.length; i++) {

                        row_after = $("<div class='col-sm-3 text-center'>");
                        //if (res.result[i].filename != '' && res.result[i].filename != null && res.result[i].filename != 'NULL' && res.result[i].ImageDetails_AnnotatedImagePath != '' && res.result[i].ImageDetails_AnnotatedImagePath != null && res.result[i].ImageDetails_AnnotatedImagePath != 'NULL' && res.result[i].ImageDetails_RawImagePath != '' && res.result[i].ImageDetails_RawImagePath != null && res.result[i].ImageDetails_RawImagePath != 'NULL') {
                        //    row_after.append($("<span class='text-center'><strong>" + res.result[i].filename + "</strong></span></br>"));
                        if (res.result[i].filename != '' && res.result[i].filename != null && res.result[i].filename != 'NULL' && res.result[i].ImageDetails_RawImagePath != '' && res.result[i].ImageDetails_RawImagePath != null && res.result[i].ImageDetails_RawImagePath != 'NULL') {
                            row_after.append($("<span class='text-center'><strong>" + res.result[i].filename + "</strong></span></br>"));


                            //row_after.append($("<a href='#ocas-popup" + i + "' data-toggle='modal'> <span class='popup-thumnail'><img src='" + res.result[i].ImageDetails_AnnotatedImagePath + "' class='img-fluid rounded'></span> </a>"));
                            row_after.append($("<a href='#ocas-popup" + i + "' data-toggle='modal'> <span class='popup-thumnail'><img src='" + res.result[i].ImageDetails_RawImagePath + "' class='img-fluid rounded'></span> </a>"));


                            //row_after.append("</div>");
                            //Model_after = $("<div class='modal fade ocas_modal' id='ocas-popup" + i + "' tabindex='-1' role='dialog' aria-labelledby='exampleModalLabel' aria-hidden='true'>" +
                            //    "<div class='modal-dialog' role='document'>" +
                            //    "<div class='modal-content'>" +
                            //    "<div class='modal-body'>" +
                            //    "<a class='close' data-dismiss='modal'><img src='Content/img/popup-cross.png' alt=''></a>" +
                            //    "<div class='image_wrapper'>" +
                            //    "<div class='img_block'>" +
                            //    "<a href='" + res.result[i].ImageDetails_RawImagePath + "' data-fancybox='images'>" +
                            //    "<img src='" + res.result[i].ImageDetails_RawImagePath + "' alt=''>" +
                            //    "</a>" +
                            //    "<div class='download_img'>" +
                            //    "<a href='" + res.result[i].ImageDetails_RawImagePath + "' download='" + JobCardNo + "-media-files-" + i + "' target='_blank'>Download</a>" +
                            //    "</div>	" +
                            //    "</div>" +
                            //    "<div class='img_block'>" +
                            //    "<a href='" + res.result[i].ImageDetails_RawImagePath + "' data-fancybox='images'>" +
                            //    "<img src='" + res.result[i].ImageDetails_RawImagePath + "' alt=''>" +
                            //    "</a>" +
                            //    "<div class='download_img'>" +
                            //    "<a href='" + res.result[i].ImageDetails_RawImagePath + "' download='" + JobCardNo + "-annoted-media-files-" + i + "' target='_blank'>Download</a>" +
                            //    "</div>" +
                            //    "</div>" +
                            //    "</div>" +
                            //    "</div>" +
                            //    "</div>" +
                            //    "</div>" +
                            //    "</div>");
                            row_after.append("</div>");
                            Model_after = $("<div class='modal fade ocas_modal' id='ocas-popup" + i + "' tabindex='-1' role='dialog' aria-labelledby='exampleModalLabel' aria-hidden='true'>" +
                                "<div class='modal-dialog' role='document' style='max-width:1000px'>" +
                                "<div class='modal-content'>" +
                                "<div class='modal-body'>" +
                                "<a class='close' data-dismiss='modal'><img src='Content/img/popup-cross.png' alt=''></a>" +
                                "<div class='image_wrapper'>" +
                                "<div class='img_block' style='width: 100%'>" +
                                "<a href='" + res.result[i].ImageDetails_RawImagePath + "' data-fancybox='images'>" +
                                "<img src='" + res.result[i].ImageDetails_RawImagePath + "' alt=''>" +
                                "</a>" +
                                "<div class='download_img'>" +
                                "<a href='" + res.result[i].ImageDetails_RawImagePath + "' download='" + JobCardNo + "-media-files-" + i + "' target='_blank'>Download</a>" +
                                "</div>	" +
                                "</div>" +
                                
                                "</div>" +
                                "</div>" +
                                "</div>" +
                                "</div>" +
                                "</div>");
                        }
                        else {
                            row_after.append($("<span class='text-center'></span></br>"));
                        }

                        $("#partialviewafter .row").append(row_after);
                        $("#partialviewafter .Popup-model-collection").append(Model_after);

                        Image_Count++;
                        links_url[Image_Count] = res.result[i].ImageDetails_RawImagePath;
                        Image_Count++;
                        links_url[Image_Count] = res.result[i].ImageDetails_AnnotatedImagePath;
                    }
                    GetdownloadUrl();
                }
                else {

                    //$('.alertmsg').text('Media data not found.');
                    //$("#alert-popup").show();
                    //setTimeout(function () {
                    //    $('#alert-popup').fadeOut('fast');
                    //}, 1000);
                }
            }
            else {
                $('.alertmsg').text('Media data not found.');
                $("#alert-popup").show();
                setTimeout(function () {
                    $('#alert-popup').fadeOut('fast');
                }, 1000);
            }
            objData = null;
        }).fail(function (jqXHR, status, error) {
            ErrorLogger(jqXHR, status, error);
            });
        APIModule.Call('POST', BaseUrl + '/Home/GetCQImageDetailsUnderBody', JSON.stringify(objData)).done(function (data) {

            if (data != '') {
                var res = data;
                var row = '';
                var row1 = '';
                var Model1 = '';

                if (res.result != null && res.message == 'Success') {

                    $("#partialviewUnderbody .row").html('');
                    $("#partialviewUnderbody .row").append(row1);
                    $("#partialviewUnderbody .Popup-model-collection").html('');
                    $("#partialviewUnderbody .Popup-model-collection").append(Model1);

                    for (var i = 0; i < res.result.length; i++) {

                        row1 = $("<div class='col-sm-3 text-center'>");
                        if (res.result[i].filename != '' && res.result[i].filename != null && res.result[i].filename != 'NULL' && res.result[i].ImageDetails_AnnotatedImagePath != '' && res.result[i].ImageDetails_AnnotatedImagePath != null && res.result[i].ImageDetails_AnnotatedImagePath != 'NULL' && res.result[i].ImageDetails_RawImagePath != '' && res.result[i].ImageDetails_RawImagePath != null && res.result[i].ImageDetails_RawImagePath != 'NULL') {
                            row1.append($("<span class='text-center'><strong>" + res.result[i].filename + "</strong></span></br>"));
                            //row1.append($("<span style='font-size:x-small;'>" + res.result[i].filename.split('$')[0].split('.')[0].replace("/", "") + "</span>"));
                            if (res.result[i].ImageDetails_AnnotatedImagePath != null && res.result[i].ImageDetails_AnnotatedImagePath != '' && res.result[i].ImageDetails_AnnotatedImagePath != 'NULL') {
                                row1.append($("<a href='#ocas-popup-underbody" + i + "' data-toggle='modal'> <span class='popup-thumnail'><img src='" + res.result[i].ImageDetails_AnnotatedImagePath + "' class='img-fluid rounded'></span> </a>"));
                                row1.append($("<a href=" + res.result[i].ImageDetails_AnnotatedImagePath + " download=" + JobCardNo + '-' + 'media-files-' + i + " target='_self' class='fancydownload'>Download</a>"));
                            }
                            else {
                                row1.append($("<a href='#ocas-popup-underbody" + i + "' data-toggle='modal'> <span class='popup-thumnail'><img src='" + res.result[i].ImageDetails_RawImagePath + "' class='img-fluid rounded'></span> </a>"));
                                row1.append($("<a href=" + res.result[i].ImageDetails_RawImagePath + " download=" + JobCardNo + '-' + 'media-files-' + i + " target='_self' class='fancydownload'>Download</a>"));
                            }
                            row1.append("</div>");

                            Model1 = $("<div class='modal fade' id='ocas-popup-underbody" + i + "' tabindex='-1' role='dialog' aria-labelledby='exampleModalLabel' aria-hidden='true'>" +
                                "<div class='modal-dialog' role='document'>" +
                                "<div class='modal-content'>" +
                                "<div class='modal-body'>" +
                                "<a class='close' data-dismiss='modal'><img src='Content/img/popup-cross.png' alt=''></a>" +
                                "<div class='image_wrapper'>" +
                                "<div class='img_block'>" +
                                "<a href='" + res.result[i].ImageDetails_RawImagePath + "' data-fancybox='images'>" +
                                "<img src='" + res.result[i].ImageDetails_RawImagePath + "' alt=''>" +
                                "</a>" +
                                "<div class='download_img'>" +
                                // "<a href='" + res.result[i].ImageDetails_RawImagePath.replace("https://customerapproval.marutisuzuki.com/", "/") + "' download='" + JobCardNo + "-media-files-" + i + "' target='_self' class='fancydownload'>Download</a>" +
                                "<a href='" + res.result[i].ImageDetails_RawImagePath + "' download='" + JobCardNo + "-media-files-" + i + "' target='_blank'>Download</a>" +
                                "</div>	" +
                                "</div>" +
                                "<div class='img_block'>" +
                                "<a href='" + res.result[i].ImageDetails_AnnotatedImagePath + "' data-fancybox='images'>" +
                                "<img src='" + res.result[i].ImageDetails_AnnotatedImagePath + "' alt=''>" +
                                "</a>" +
                                "<div class='download_img'>" +
                                "<a href='" + res.result[i].ImageDetails_AnnotatedImagePath + "' download='" + JobCardNo + "-annoted-media-files-" + i + "' target='_blank'>Download</a>" +
                                "</div>" +
                                "</div>" +
                                "</div>" +
                                "</div>" +
                                "</div>" +
                                "</div>" +
                                "</div>");

                        }
                        else if (res.result[i].filename != '' || res.result[i].filename == 'video' || res.result[i].filename == 'Video' || res.result[i].ImageDetails_AnnotatedImagePath == '' || res.result[i].ImageDetails_AnnotatedImagePath == null) {
                            row1 = $("<div class='col-sm-3 text-center'>");
                            if (res.result[i].filename != '' && res.result[i].filename != null && res.result[i].filename != 'NULL') {
                                row1.append($("<span class='text-center'><strong>" + res.result[i].filename + "</strong></span></br>"));
                            }
                            else {
                                row1.append($("<span class='text-center'></span></br>"));
                            }
                            // row1.append($("<span style='font-size:x-small;'>" + res.result[i].filename.split('$')[0].split('.')[0].replace("/", "") + "</span>"));
                            //row1.append($("<a href= " + BaseUrl + "/Content/img/video-play-icon.png data-toggle='lightbox' data-gallery='gallery' download=" + JobCardNo + '-' + 'media-files-' + i + " target='_self'><span class='popup-thumnail'><img src=" + BaseUrl + "/Content/img/video-play-icon.png class='img-fluid rounded'></span><a href='" + res.media[0].MediaDetails[i].MediaPath.replace("http://104.211.200.64/", "/") + "'  download=" + JobCardNo + '-' + 'media-files-' + i + " target='_self' class='fancydownload'>Download</a></a>"));
                            row1.append($("<a target='_blank' href='" + res.result[i].ImageDetails_AnnotatedImagePath.replace("http://104.211.200.64/", "/") + "'><span class='popup-thumnail'><img src=" + BaseUrl + "/Content/img/video-play-icon.png class='img-fluid rounded'></span></a>"));
                            row1.append($("<a href=" + res.result[i].ImageDetails_AnnotatedImagePath + " download=" + JobCardNo + '-' + 'media-files-' + i + " target='_self' class='fancydownload'>Download</a>"));
                            row1.append("</div>");
                        }
                        else {
                            row1.append($("<span class='text-center'></span></br>"));
                        }

                        $("#partialviewUnderbody .row").append(row1);
                        $("#partialviewUnderbody .Popup-model-collection").append(Model1);

                        Image_Count++;
                        links_url[Image_Count] = res.result[i].ImageDetails_AnnotatedImagePath;
                        Image_Count++
                        links_url[Image_Count] = res.result[i].ImageDetails_AnnotatedImagePath;
                    }
                    GetdownloadUrl();
                }
                else {

                    //$('.alertmsg').text('Media data not found.');
                    //$("#alert-popup").show();
                    //setTimeout(function () {
                    //    $('#alert-popup').fadeOut('fast');
                    //}, 1000);
                }
            }
            else {
                $('.alertmsg').text('Media data not found.');
                $("#alert-popup").show();
                setTimeout(function () {
                    $('#alert-popup').fadeOut('fast');
                }, 1000);
            }
            objData = null;
        }).fail(function (jqXHR, status, error) {
            ErrorLogger(jqXHR, status, error);
        });
    }
}
function GetJCWarrantyMedia_PDI(JobCardNo, Vin) {
    event.preventDefault();
    $("#partialviewmedia").show();
    $("#videodownload").hide();
    $("#partialviewmedia .row").html('');
    //  $("#partialviewaudiomedia .row").html('');
    $("#partialviewbefore .row").html('');
    $("#partialviewafter .row").html('');

    $("#partialviewdefectmedia .row").html('');
    $("#btndownloaddoc").hide();
    links_url = [];
    Doclinks_url = [];
    var hasInput = false;
    if (JobCardNo != '' && Vin != '') {
        objData = {};
        objData.JCNo = JobCardNo;
        objData.Vin = Vin;
        hasInput = true;
    }
    if (!hasInput) {
        alert('OCAS media data not found.');
        $("#videodownload").hide();
        $("#partialviewmedia .row").html('');
        $("#partialviewaudiomedia .row").html('');
        // $("#partialviewbefore .row").html('');
        $("#partialviewdefectmedia .row").html('');
        $("#btndownloaddoc").hide();
    }
    else {
        APIModule.Call('POST', BaseUrl + '/Home/GetPDIJCWarrantyMedia', JSON.stringify(objData)).done(function (data) {

            if (data != '') {
                var res = JSON.parse(data);
                var row = '';
                var row1 = '';
                var row2 = '';
                if (res.result == 'success' && res.media != null && res.media[0].MediaDetails != null && res.media[0].MediaDetails.length > 0) {

                    $("#partialviewmedia .row").html('');
                    $("#partialviewmedia .row").append(row);
                    $("#partialviewaudiomedia .row").html('');
                    $("#partialviewaudiomedia .row").append(row1);
                    $("#partialviewdefectmedia .row").html('');
                    $("#partialviewdefectmedia .row").append(row2);

                    for (var i = 0; i < res.media[0].MediaDetails.length; i++) {

                        var ext = res.media[0].MediaDetails[i].MediaPath.split('.').pop();
                        var mediaType = res.media[0].MediaDetails[i].MediaType;
                        if (ext != '' && ext == 'mp4' && (mediaType == 'M')) {

                            /*row1=$("<div class='col-sm-3 text-center'>");
                            row1.append($("<a href=" + res.media[0].MediaDetails[i].MediaPath + " data-toggle='lightbox' data-gallery='gallery' download=" + JobCardNo + '-' + 'media-files-' + i + " target='_self'><span class='popup-thumnail'><img src='/Content/img/v-play-icon.jpg' class='img-fluid rounded' style='width:125px; height:130px;'></span></a><a href=" + res.media[0].MediaDetails[i].MediaPath + " download=" + JobCardNo + '-' + 'media-files-' + i + " target='_self' class='fancydownload'>Download</a></div>"));*/

                            $("#videodownload").show();
                            $("#video_url_mtab").attr("src", res.media[0].MediaDetails[i].MediaPath);
                            $("#video_url").attr("href", res.media[0].MediaDetails[i].MediaPath);
                            $("#video_url").attr("download", JobCardNo + '-' + 'media-files-' + i);
                        }
                        else if (ext != '' && ext == 'jpg' || ext == 'jpeg' && mediaType == 'M') {
                            row1 = $("<div class='col-sm-3 text-center'>");
                            row1.append($("<a href=" + res.media[0].MediaDetails[i].MediaPath + " data-toggle='lightbox' data-gallery='gallery' download=" + JobCardNo + '-' + 'media-files-' + i + " target='_self'><span class='popup-thumnail'><img src=" + res.media[0].MediaDetails[i].MediaPath + " class='img-fluid rounded'></span><a href='" + res.media[0].MediaDetails[i].MediaPath + "'  download=" + JobCardNo + '-' + 'media-files-' + i + " target='_self' class='fancydownload'>Download</a></a>"));
                            row1.append("</div>");
                        }
                        /* else if (ext != '' && ext == 'jpg' && mediaType == 'D') {
                        row2 = $("<div class='col-sm-3 text-center'>");
                        row2.append($("<a href=" + res.media[0].MediaDetails[i].MediaPath + " data-toggle='lightbox' data-gallery='gallery' download=" + JobCardNo + '-' + 'media-files-' + i + " target='_self'><span class='popup-thumnail'><img src=" + res.media[0].MediaDetails[i].MediaPath + " class='img-fluid rounded'></span><a href='" + res.media[0].MediaDetails[i].MediaPath + "'  download=" + JobCardNo + '-' + 'media-files-' + i + " target='_self' class='fancydownload'>Download</a></a>"));
                        row2.append("</div>");
                        }*/
                        else if (ext != '' && (ext == 'jpg' || ext == 'jpeg' || ext == 'mp4') && mediaType == 'D') {
                            if (ext == 'mp4') {
                                row2 = $("<div class='col-sm-3 text-center'>");
                                row2.append($("<a href=https://customerapproval.marutisuzuki.com/" + res.media[0].MediaDetails[i].MediaPath + " data-toggle='lightbox' data-gallery='gallery' download=" + JobCardNo + '-' + 'media-files-' + i + " target='_self'><span class='popup-thumnail'><img src='https://customerapproval.marutisuzuki.com/MTabWarrantyMedia_QA/Content/img/v-play-icon.jpg' class='img-fluid rounded' style='width:125px; height:130px;'></span><a href=" + res.media[0].MediaDetails[i].MediaPath + "  download=" + JobCardNo + '-' + 'media-files-' + i + " target='_self' class='fancydownload'>Download</a></a>"));
                                row2.append("</div>");
                            }
                            else {
                                row2 = $("<div class='col-sm-3 text-center'>");
                                row2.append($("<a href=" + res.media[0].MediaDetails[i].MediaPath + " data-toggle='lightbox' data-gallery='gallery' download=" + JobCardNo + '-' + 'media-files-' + i + " target='_self'><span class='popup-thumnail'><img src=" + res.media[0].MediaDetails[i].MediaPath + " class='img-fluid rounded'></span><a href='" + res.media[0].MediaDetails[i].MediaPath + "'  download=" + JobCardNo + '-' + 'media-files-' + i + " target='_self' class='fancydownload'>Download</a></a>"));
                                row2.append("</div>");
                            }
                        }
                        else if (ext != '' && (ext == 'pdf' || ext == 'doc' || ext == 'ppt') && mediaType == 'DOC') {

                            Doclinks_url[0] = res.media[0].MediaDetails[i].MediaPath;
                            $("#btndownloaddoc").show();

                            //row2 = $("<div class='col-sm-3 text-center'>");
                            //row2.append($("<a href=" + res.media[0].MediaDetails[i].MediaPath + " data-toggle='lightbox' data-gallery='gallery' download=" + JobCardNo + '-' + 'media-files-' + i + " target='_self'><span class='popup-thumnail'><img src='~/Content/img/download_icon.png' class='img-fluid rounded'></span><a href='" + res.media[0].MediaDetails[i].MediaPath + "'  download=" + JobCardNo + '-' + 'media-files-' + i + " target='_self' class='fancydownload'>Download</a></a>"));
                            //row2.append("</div>");
                        }
                        /*else if (ext != '' && ext == 'wav' && (ext == 'AUD')) {
                        row = $("<div class='col-sm-4 text-center'><div class='audio_bg'><audio controls class='audio_width'><source src=" + res.media[0].MediaDetails[i].MediaPath + "  type='audio/ogg'><source src=" + res.media[0].MediaDetails[i].MediaPath + "  type='audio/mpeg'></audio> </div>");
                        row.append($("<a href=" + res.media[0].MediaDetails[i].MediaPath + "  download=" + JobCardNo + '-' + 'media-files-' + i + " target='_self' class='btn btn-dark btn-block'>Download</a><br/>"));
                        row.append("</div>");
                        }*/
                        $("#partialviewmedia .row").append(row);
                        $("#partialviewaudiomedia .row").append(row1);
                        $("#partialviewdefectmedia .row").append(row2);
                        links_url[i] = res.media[0].MediaDetails[i].MediaPath;
                    }
                    GetdownloadUrl();
                }
                else {

                    $('.alertmsg').text('Media data not found.');
                    $("#alert-popup").show();
                    setTimeout(function () {
                        $('#alert-popup').fadeOut('fast');
                    }, 1000);
                }
            }
            else {
                $('.alertmsg').text('Media data not found.');
                $("#alert-popup").show();
                setTimeout(function () {
                    $('#alert-popup').fadeOut('fast');
                }, 1000);
            }
            objData = null;
        }).fail(function (jqXHR, status, error) {
            ErrorLogger(jqXHR, status, error);
        });
    }
}
function GetdownloadUrl() {
    imgurl = '';
    for (var i = 0; i < links_url.length; i++) {
        imgurl += links_url[i] + ',';
    }
    links = imgurl;
}
function downloadAll(urls) {
    if (urls == '') {
        alert('No record found.');
    }
    else {
        var link = document.createElement('a');
        link.style.display = 'none';
        document.body.appendChild(link);
        for (var i = 0; i < urls.length; i++) {
            link.setAttribute('href', urls[i]);
            link.setAttribute('download', JobCardNo + '-' + 'media-files' + i);
            link.click();
        }
        document.body.removeChild(link);
    }
}

$(function () {
    $('#SendEmail').click(function (event) {
        var email = 'mukeshh.sinha@gmail.com';
        var subject = 'Test';
        var emailBody = 'Hi Sample,';
        var attach = links;
        document.location = "mailto:" + email + "?subject=" + subject + "&body=" + emailBody + "?attach=" + attach;
    });
});
function isNumber(evt) {
    evt = (evt) ? evt : window.event;
    var charCode = (evt.which) ? evt.which : evt.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
        return false;
    }
    return true;
}
function isAlphabet(evt) {
    evt = (evt) ? evt : window.event;
    var charCode = (evt.which) ? evt.which : evt.keyCode;
    if ((charCode > 64 && charCode < 91) || (charCode > 96 && charCode < 123) || (charCode == 8) || (charCode == 9) || (charCode == 32)) {
        return true;
    }
    return false;
}
$('#txtJobCardNo, #txtRegNo').keypress(function (e) {
    var regex = new RegExp("^[a-zA-Z0-9]+$");
    var str = String.fromCharCode(!e.charCode ? e.which : e.charCode);
    if (regex.test(str)) {
        return true;
    }
    e.preventDefault();
    return false;
});

$('#download-all').click(function (event) {
    event.preventDefault();
    $('.my-file').multiDownload();
});

$('#btnReset').click(function (event) {
    event.preventDefault();
    ClearControl();
    ClearMediaList();
});
//function is used to autocomplete the dealer code text box fields.
function GetDealerCode() {
    JCWarranty = {};
    $("#txtDealerCode").autocomplete({
        source: function (request, response) {
            JCWarranty.DealerMapCd = $("#txtDealerCode").val();
            $.ajax({
                url: BaseUrl + "/Home/GetDealerCode",
                data: JSON.stringify(JCWarranty),
                dataType: "json",
                type: "POST",
                contentType: "application/json; charset=utf-8",
                dataFilter: function (data) { return data; },
                success: function (data) {
                    response($.map(data, function (item) {
                        return {
                            value: item
                        }
                    }))
                },
                error: function (XMLHttpRequest, textStatus, errorThrown) {
                    alert(textStatus);
                }
            });
        },
        minLength: 2
    });
}

function GetPDIDealerCode() {
    JCWarranty = {};
    $("#txtDealerCode").autocomplete({
        source: function (request, response) {
            JCWarranty.DealerMapCd = $("#txtDealerCode").val();
            $.ajax({
                url: BaseUrl + "/Home/GetPDIDealerCode",
                data: JSON.stringify(JCWarranty),
                dataType: "json",
                type: "POST",
                contentType: "application/json; charset=utf-8",
                dataFilter: function (data) { return data; },
                success: function (data) {
                    response($.map(data, function (item) {
                        return {
                            value: item
                        }
                    }))
                },
                error: function (XMLHttpRequest, textStatus, errorThrown) {
                    alert(textStatus);
                }
            });
        },
        minLength: 2
    });
}

function validateEmail(email) {
    var regex = /^([a-zA-Z0-9_.+-])+\@(([a-zA-Z0-9-])+\.)+([a-zA-Z0-9]{2,4})+$/;
    return regex.test(email);
}

$('#btnSendEmail').click(function (event) {
    debugger;
    var hasInput = false;
    JCEMail = {};

    hasInput = VailidateEmailInputs();
    if (hasInput && links_url.length > 0) {
        JCEMail.JCNo = JobCardNo;
        JCEMail.RegistrationNo = RegNo
        JCEMail.ToAddress = $('#txtToEmail').val();
        JCEMail.CCAddress = $('#txtCcEmail').val();

        if (_MediaType === 'OCAS')
            JCEMail.Subject = 'Media File of JobCard No - ' + JobCardNo + ' & RegNo - ' + RegNo;
        else
            JCEMail.Subject = 'Media File of JobCard No - ' + JobCardNo + ' & Vin - ' + Vin;

        JCEMail.MediaAttachment = links_url;
        APIModule.Call('POST', BaseUrl + '/Home/SendEmail', JSON.stringify(JCEMail)).done(function (response) {

            if (response != '') {
                if (response.result == 'failure') {
                    $('#myModal').modal('hide');
                    ClearEmailControl();
                }
                else if (response.result == 'success') {
                    $('#myModal').modal('hide');
                    ClearEmailControl();
                }
            }
            else {

            }
        }).fail(function (jqXHR, status, error) {
            ErrorLogger(jqXHR, status, error);
        });
    }
});

function VailidateEmailInputs() {
    var hasInput = false;
    if (validateEmail($('#txtToEmail').val()) && $('#txtToEmail').val != '') {
        hasInput = true;
    }
    else if ($('#txtCcEmail').val != '' && validateEmail($('#txtCcEmail').val())) {
        hasInput = true;
    }
    else if ($('#txtToEmail').val == '') {

        alert("Please fill the email id.");
        hasInput = false;
    }
    else {
        alert("Please enter vailid email id.");
        hasInput = false;
    }
    return hasInput;
}
function ClearEmailControl() {
    $("#txtToEmail").val('');
    $("#txtCcEmail").val('');
}
document.addEventListener('play', function (e) {
    var audios = document.getElementsByTagName('audio');
    for (var i = 0, len = audios.length; i < len; i++) {
        if (audios[i] != e.target) {
            audios[i].pause();
        }
    }
}, true);







